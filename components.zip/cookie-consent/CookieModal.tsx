import { X } from 'lucide-react';
import { CookieButton } from './CookieButton';
import { CookieCategoryRow } from './CookieCategoryRow';

interface CookiePreferences {
  essential: boolean;
  analytics: boolean;
  functional: boolean;
  marketing: boolean;
}

interface CookieModalProps {
  isOpen: boolean;
  onClose: () => void;
  preferences: CookiePreferences;
  onPreferencesChange: (preferences: CookiePreferences) => void;
  onSavePreferences: () => void;
  onAcceptAll: () => void;
  onRejectAll: () => void;
  theme?: 'light' | 'dark';
}

export function CookieModal({
  isOpen,
  onClose,
  preferences,
  onPreferencesChange,
  onSavePreferences,
  onAcceptAll,
  onRejectAll,
  theme = 'light'
}: CookieModalProps) {
  if (!isOpen) return null;

  const categories = [
    {
      id: 'essential',
      title: 'Essential',
      description: 'Required for core website functionality and security.',
      checked: preferences.essential,
      disabled: true
    },
    {
      id: 'analytics',
      title: 'Analytics',
      description: 'Helps us understand how visitors use the site.',
      checked: preferences.analytics,
      disabled: false
    },
    {
      id: 'functional',
      title: 'Functional',
      description: 'Remembers preferences such as language or region.',
      checked: preferences.functional,
      disabled: false
    },
    {
      id: 'marketing',
      title: 'Marketing',
      description: 'Used for advertising and tracking across websites.',
      checked: preferences.marketing,
      disabled: false
    }
  ];

  const handleToggle = (categoryId: string, value: boolean) => {
    onPreferencesChange({
      ...preferences,
      [categoryId]: value
    });
  };

  const backdropColor = theme === 'dark' ? 'bg-black/70' : 'bg-slate-900/50';
  const bgColor = theme === 'dark' ? 'bg-slate-900' : 'bg-white';
  const borderColor = theme === 'dark' ? 'border-slate-800' : 'border-slate-200';
  const titleColor = theme === 'dark' ? 'text-slate-100' : 'text-slate-900';
  const textColor = theme === 'dark' ? 'text-slate-300' : 'text-slate-600';
  const iconColor = theme === 'dark' ? 'text-slate-400' : 'text-slate-600';
  const hoverBg = theme === 'dark' ? 'hover:bg-slate-800' : 'hover:bg-slate-100';
  const footerBg = theme === 'dark' ? 'bg-slate-950' : 'bg-slate-50';
  const shadowStyle = theme === 'dark' ? 'shadow-2xl shadow-black/40' : 'shadow-lg';

  return (
    <>
      {/* Backdrop */}
      <div 
        className={`fixed inset-0 ${backdropColor} z-50 transition-opacity backdrop-blur-sm`}
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div 
          className={`${bgColor} rounded-2xl ${shadowStyle} border ${borderColor} w-full max-w-2xl max-h-[90vh] flex flex-col`}
          role="dialog"
          aria-modal="true"
          aria-labelledby="cookie-modal-title"
        >
          {/* Header */}
          <div className={`flex items-center justify-between px-6 sm:px-8 py-5 border-b ${borderColor}`}>
            <h2 id="cookie-modal-title" className={`text-xl font-medium ${titleColor} tracking-tight`}>
              Cookie Preferences
            </h2>
            <button
              onClick={onClose}
              className={`p-2 rounded-full ${hoverBg} transition-colors`}
              aria-label="Close modal"
            >
              <X className={`w-5 h-5 ${iconColor}`} />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-6 sm:px-8 py-6">
            <p className={`text-sm ${textColor} leading-relaxed mb-6`}>
              We use cookies to enhance your browsing experience and analyze our traffic. 
              Please choose which types of cookies you consent to. Essential cookies cannot 
              be disabled as they are necessary for the website to function.
            </p>

            <div className="space-y-0">
              {categories.map((category) => (
                <CookieCategoryRow
                  key={category.id}
                  title={category.title}
                  description={category.description}
                  checked={category.checked}
                  onChange={(value) => handleToggle(category.id, value)}
                  disabled={category.disabled}
                  theme={theme}
                />
              ))}
            </div>
          </div>

          {/* Footer - Desktop */}
          <div className={`hidden sm:flex items-center justify-between gap-3 px-6 sm:px-8 py-5 border-t ${borderColor} ${footerBg}`}>
            <CookieButton type="tertiary" onClick={onRejectAll} theme={theme}>
              Reject all
            </CookieButton>
            <div className="flex gap-3">
              <CookieButton type="secondary" onClick={onAcceptAll} theme={theme}>
                Accept all
              </CookieButton>
              <CookieButton type="primary" onClick={onSavePreferences} theme={theme}>
                Save preferences
              </CookieButton>
            </div>
          </div>

          {/* Footer - Mobile */}
          <div className={`sm:hidden flex flex-col gap-2 px-6 py-5 border-t ${borderColor} ${footerBg}`}>
            <CookieButton type="primary" onClick={onSavePreferences} fullWidth theme={theme}>
              Save preferences
            </CookieButton>
            <div className="flex gap-2">
              <CookieButton type="secondary" onClick={onAcceptAll} fullWidth theme={theme}>
                Accept all
              </CookieButton>
              <CookieButton type="tertiary" onClick={onRejectAll} fullWidth theme={theme}>
                Reject all
              </CookieButton>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}