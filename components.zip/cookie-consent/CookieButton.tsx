interface CookieButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  type?: 'primary' | 'secondary' | 'tertiary';
  disabled?: boolean;
  fullWidth?: boolean;
  theme?: 'light' | 'dark';
}

export function CookieButton({
  children,
  onClick,
  type = 'primary',
  disabled = false,
  fullWidth = false,
  theme = 'light'
}: CookieButtonProps) {
  // Match existing button styles from the website
  const baseStyles = "px-6 py-3 rounded-full text-sm transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed font-medium";
  
  const lightStyles = {
    primary: `
      bg-slate-900 text-white
      hover:bg-slate-800 active:bg-slate-950
      disabled:hover:bg-slate-900
    `,
    secondary: `
      bg-white text-slate-900 border border-slate-300
      hover:border-slate-400 hover:bg-slate-50 active:bg-slate-100
      disabled:hover:bg-white disabled:hover:border-slate-300
    `,
    tertiary: `
      bg-transparent text-slate-700
      hover:text-slate-900 hover:bg-slate-100 active:bg-slate-200
      disabled:hover:bg-transparent disabled:hover:text-slate-700
    `
  };

  const darkStyles = {
    primary: `
      bg-slate-100 text-slate-900
      hover:bg-white active:bg-slate-200
      disabled:hover:bg-slate-100
    `,
    secondary: `
      bg-transparent text-slate-100 border border-slate-600
      hover:border-slate-500 hover:bg-slate-800 active:bg-slate-700
      disabled:hover:bg-transparent disabled:hover:border-slate-600
    `,
    tertiary: `
      bg-transparent text-slate-300
      hover:text-slate-100 hover:bg-slate-800 active:bg-slate-700
      disabled:hover:bg-transparent disabled:hover:text-slate-300
    `
  };

  const typeStyles = theme === 'dark' ? darkStyles[type] : lightStyles[type];
  const widthStyles = fullWidth ? "w-full" : "";

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`${baseStyles} ${typeStyles} ${widthStyles}`}
    >
      {children}
    </button>
  );
}