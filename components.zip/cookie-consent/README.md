# Cookie Consent UI Components

Professional cookie consent system for NeoTechnology Solutions website.

## Design Specifications

### Brand & Style
- **Aesthetic**: Clean, Apple-like, consulting-grade
- **Font**: Inter (system sans-serif)
- **Colors**: 
  - Background: White
  - Text: Slate-900 (dark neutral)
  - Borders: Slate-200 (subtle)
  - Primary CTA: Slate-900 (brand color)
- **Tone**: Neutral, trustworthy, not marketing-heavy

## Components

### 1. CookieButton
**Purpose**: Reusable button component with three visual variants

**Variants**:
- `primary` - Slate-900 background, white text (main CTAs)
- `secondary` - White background, slate-900 text, border (secondary actions)
- `tertiary` - Transparent background, slate-700 text (tertiary actions)

**States**:
- Default
- Hover
- Active
- Disabled

**Props**:
```typescript
{
  children: React.ReactNode;
  onClick?: () => void;
  type?: 'primary' | 'secondary' | 'tertiary';
  disabled?: boolean;
  fullWidth?: boolean;
}
```

**Features**:
- Touch-friendly padding (px-6 py-3)
- Rounded-full corners
- Smooth transitions (200ms)
- Accessible focus states

---

### 2. CookieToggle
**Purpose**: Toggle switch for cookie category preferences

**States**:
- On (checked) - Slate-900 background
- Off (unchecked) - Slate-300 background
- Disabled (always on) - Slate-400 background, cursor-not-allowed

**Props**:
```typescript
{
  checked: boolean;
  onChange?: (checked: boolean) => void;
  disabled?: boolean;
  label?: string;
}
```

**Features**:
- 44px × 24px size (touch-friendly)
- Smooth slide animation
- Focus ring for accessibility
- ARIA role="switch"

---

### 3. CookieCategoryRow
**Purpose**: Row displaying cookie category with description and toggle

**Layout**: Auto-layout (horizontal)
- Left: Title + Description (flex-1)
- Right: Toggle (flex-shrink-0)

**Props**:
```typescript
{
  title: string;
  description: string;
  checked: boolean;
  onChange?: (checked: boolean) => void;
  disabled?: boolean;
}
```

**Categories**:
1. **Essential** (always on, disabled)
   - "Required for core website functionality and security."
2. **Analytics** (off by default)
   - "Helps us understand how visitors use the site."
3. **Functional** (off by default)
   - "Remembers preferences such as language or region."
4. **Marketing** (off by default)
   - "Used for advertising and tracking across websites."

**Features**:
- Bottom border separator (except last)
- "Always on" indicator for disabled toggles
- Responsive gap spacing

---

### 4. CookieBanner
**Purpose**: Bottom-positioned consent banner

**Desktop Layout**:
- Horizontal auto-layout
- Left: Title + Description (flex-1)
- Right: Three buttons side-by-side
- Button order: Customize | Reject all | Accept all

**Mobile Layout**:
- Vertical auto-layout
- Title + Description (full width)
- Buttons stacked:
  - Accept all (full width)
  - Reject all + Customize (50/50 split)

**Content**:
- Title: "Cookie Preferences"
- Body: "We use essential cookies to make this website work. With your consent, we may also use analytics and marketing cookies to improve performance and understand how our site is used. You can accept, reject, or customize your choices at any time."

**Props**:
```typescript
{
  onAcceptAll: () => void;
  onRejectAll: () => void;
  onCustomize: () => void;
}
```

**Features**:
- Fixed bottom positioning
- Border-top + shadow-lg
- Responsive breakpoint at md (768px)
- Max-width container (7xl)

---

### 5. CookieModal
**Purpose**: Centered preferences modal for detailed cookie management

**Layout**:
- Vertical auto-layout
- Header: Title + Close button
- Content: Description + Category list (scrollable)
- Footer: Action buttons

**Desktop Footer**:
- Left: Reject all (tertiary)
- Right: Accept all (secondary) + Save preferences (primary)

**Mobile Footer**:
- Stacked:
  - Save preferences (full width, primary)
  - Accept all + Reject all (50/50 split)

**Props**:
```typescript
{
  isOpen: boolean;
  onClose: () => void;
  preferences: CookiePreferences;
  onPreferencesChange: (preferences: CookiePreferences) => void;
  onSavePreferences: () => void;
  onAcceptAll: () => void;
  onRejectAll: () => void;
}
```

**Features**:
- Backdrop overlay (50% black)
- Rounded-3xl container
- Max-width: 2xl (672px)
- Max-height: 90vh with scrollable content
- ARIA dialog attributes
- ESC key to close

---

### 6. CookieConsent (Main Component)
**Purpose**: State management and orchestration

**Features**:
- LocalStorage persistence
- Checks for existing consent
- 1-second delay before showing banner
- Manages banner/modal visibility
- Handles all user actions
- Analytics/marketing script initialization

**Storage Keys**:
- `neotechnology-cookie-consent` - Boolean consent flag
- `neotechnology-cookie-preferences` - JSON preferences object

**User Flow**:
1. First visit → Show banner (after 1s delay)
2. Accept all → Save all preferences as true
3. Reject all → Save only essential as true
4. Customize → Open modal
5. Save preferences → Store and close
6. Close modal without saving → Show banner again if no consent
7. Returning visit → Load saved preferences

---

## Design Rules

### Spacing
- Section padding: py-4 sm:py-6
- Component gap: gap-3 to gap-6
- Touch targets: min 44px height

### Typography
- Title: text-lg to text-2xl, font-medium
- Body: text-sm, text-slate-600
- Button text: text-sm, font-medium

### Colors
- Primary action: bg-slate-900
- Secondary action: border-slate-300
- Tertiary action: text-slate-700
- Toggle on: bg-slate-900
- Toggle off: bg-slate-300

### Accessibility
- Focus rings on all interactive elements
- ARIA labels and roles
- Keyboard navigation support
- High contrast text (WCAG AA compliant)
- Touch-friendly tap targets (44px minimum)

### Responsive Breakpoints
- Mobile: default
- Desktop: md (768px) and above
- Max container width: 7xl (1280px) for banner, 2xl (672px) for modal

---

## Integration

Add to your main App component:

```tsx
import { CookieConsent } from './components/cookie-consent/CookieConsent';

function App() {
  return (
    <div>
      {/* Your app content */}
      <CookieConsent />
    </div>
  );
}
```

The component automatically:
- Checks for existing consent
- Shows banner on first visit
- Persists user choices
- Provides modal for customization
- Loads preferences on return visits

---

## Developer Handoff Notes

### File Structure
```
/components/cookie-consent/
  ├── CookieButton.tsx       - Button component with variants
  ├── CookieToggle.tsx       - Toggle switch component
  ├── CookieCategoryRow.tsx  - Category row with toggle
  ├── CookieBanner.tsx       - Bottom banner UI
  ├── CookieModal.tsx        - Preferences modal UI
  ├── CookieConsent.tsx      - Main orchestration component
  └── README.md              - This file
```

### Dependencies
- React 18+
- Tailwind CSS
- lucide-react (for icons: X)

### No Pre-Selected Toggles
Essential cookies are the only category enabled by default (and cannot be disabled).
All other categories start as `false`.

### Button Sizing
Accept and Reject buttons are always equal size in all layouts.

### Analytics Integration
The `saveConsent()` function in `CookieConsent.tsx` includes placeholder 
console.logs where you should initialize your analytics/marketing scripts:

```typescript
if (prefs.analytics) {
  // Initialize Google Analytics, etc.
}
if (prefs.marketing) {
  // Initialize Facebook Pixel, etc.
}
```

### GDPR/Privacy Compliance
- Essential cookies only by default
- Clear opt-in for analytics/marketing
- Easy to reject all
- Preferences stored locally
- Can be changed anytime
- Clear descriptions for each category

---

**Last Updated**: January 11, 2026  
**Company**: NeoTechnology Solutions LLC  
**Design System**: Apple-clean, consulting-grade
