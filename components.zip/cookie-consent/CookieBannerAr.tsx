import { CookieButton } from './CookieButton';

interface CookieBannerArProps {
  onAcceptAll: () => void;
  onRejectAll: () => void;
  onCustomize: () => void;
  theme?: 'light' | 'dark';
}

export function CookieBannerAr({
  onAcceptAll,
  onRejectAll,
  onCustomize,
  theme = 'light'
}: CookieBannerArProps) {
  const bgColor = theme === 'dark' ? 'bg-slate-900' : 'bg-white';
  const borderColor = theme === 'dark' ? 'border-slate-800' : 'border-slate-200';
  const titleColor = theme === 'dark' ? 'text-slate-100' : 'text-slate-900';
  const textColor = theme === 'dark' ? 'text-slate-300' : 'text-slate-600';
  const shadowStyle = theme === 'dark' ? 'shadow-lg shadow-black/20' : 'shadow-sm';

  return (
    <div className={`fixed bottom-0 left-0 right-0 z-50 ${bgColor} border-t ${borderColor} ${shadowStyle}`} dir="rtl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5 sm:py-6">
        {/* Desktop Layout - RTL */}
        <div className="hidden md:flex items-center justify-between gap-8">
          <div className="flex-1 min-w-0">
            <h2 className={`text-base font-semibold ${titleColor} mb-2 tracking-tight`}>
              إعدادات ملفات تعريف الارتباط
            </h2>
            <p className={`text-sm ${textColor} leading-relaxed`}>
              نستخدم ملفات تعريف الارتباط الضرورية لتشغيل هذا الموقع. وبموافقتك، قد نستخدم أيضًا ملفات تعريف ارتباط تحليلية وتسويقية لتحسين الأداء وفهم كيفية استخدام الموقع. يمكنك قبول الخيارات أو رفضها أو تخصيصها في أي وقت.
            </p>
          </div>
          
          {/* Buttons order reversed for RTL reading flow */}
          <div className="flex items-center gap-3 flex-shrink-0">
            <CookieButton type="primary" onClick={onAcceptAll} theme={theme}>
              قبول الكل
            </CookieButton>
            <CookieButton type="secondary" onClick={onRejectAll} theme={theme}>
              رفض الكل
            </CookieButton>
            <CookieButton type="tertiary" onClick={onCustomize} theme={theme}>
              تخصيص
            </CookieButton>
          </div>
        </div>

        {/* Mobile Layout - RTL */}
        <div className="md:hidden flex flex-col gap-4">
          <div>
            <h2 className={`text-base font-semibold ${titleColor} mb-2 tracking-tight`}>
              إعدادات ملفات تعريف الارتباط
            </h2>
            <p className={`text-sm ${textColor} leading-relaxed`}>
              نستخدم ملفات تعريف الارتباط الضرورية لتشغيل هذا الموقع. وبموافقتك، قد نستخدم أيضًا ملفات تعريف ارتباط تحليلية وتسويقية لتحسين الأداء وفهم كيفية استخدام الموقع.
            </p>
          </div>
          
          <div className="flex flex-col gap-2">
            <CookieButton type="primary" onClick={onAcceptAll} fullWidth theme={theme}>
              قبول الكل
            </CookieButton>
            <div className="flex gap-2">
              <CookieButton type="secondary" onClick={onRejectAll} fullWidth theme={theme}>
                رفض الكل
              </CookieButton>
              <CookieButton type="tertiary" onClick={onCustomize} fullWidth theme={theme}>
                تخصيص
              </CookieButton>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}