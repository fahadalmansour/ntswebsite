import { useState, useEffect } from 'react';
import { CookieBanner } from './CookieBanner';
import { CookieBannerAr } from './CookieBannerAr';
import { CookieModal } from './CookieModal';
import { CookieModalAr } from './CookieModalAr';

interface CookiePreferences {
  essential: boolean;
  analytics: boolean;
  functional: boolean;
  marketing: boolean;
}

const COOKIE_CONSENT_KEY = 'neotechnology-cookie-consent';
const COOKIE_PREFERENCES_KEY = 'neotechnology-cookie-preferences';

interface CookieConsentProps {
  language?: 'en' | 'ar';
  theme?: 'light' | 'dark';
}

export function CookieConsent({ language = 'en', theme = 'light' }: CookieConsentProps) {
  const [showBanner, setShowBanner] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [preferences, setPreferences] = useState<CookiePreferences>({
    essential: true,
    analytics: false,
    functional: false,
    marketing: false
  });

  // Detect language from HTML element if not provided
  const currentLanguage = language || (document.documentElement.lang === 'ar' ? 'ar' : 'en');
  const isArabic = currentLanguage === 'ar';

  // Detect theme from HTML element if not provided
  const currentTheme = theme || (document.documentElement.classList.contains('dark') ? 'dark' : 'light');

  useEffect(() => {
    // Check if user has already made a choice
    const hasConsent = localStorage.getItem(COOKIE_CONSENT_KEY);
    
    if (!hasConsent) {
      // Show banner after a short delay for better UX
      setTimeout(() => {
        setShowBanner(true);
      }, 1000);
    } else {
      // Load saved preferences
      const savedPreferences = localStorage.getItem(COOKIE_PREFERENCES_KEY);
      if (savedPreferences) {
        try {
          setPreferences(JSON.parse(savedPreferences));
        } catch (e) {
          console.error('Failed to parse cookie preferences', e);
        }
      }
    }
  }, []);

  const saveConsent = (prefs: CookiePreferences) => {
    localStorage.setItem(COOKIE_CONSENT_KEY, 'true');
    localStorage.setItem(COOKIE_PREFERENCES_KEY, JSON.stringify(prefs));
    setPreferences(prefs);
    setShowBanner(false);
    setShowModal(false);

    // Here you would typically initialize analytics/marketing scripts based on preferences
    if (prefs.analytics) {
      console.log('Analytics cookies accepted');
      // Initialize analytics (e.g., Google Analytics)
    }
    if (prefs.functional) {
      console.log('Functional cookies accepted');
      // Initialize functional features
    }
    if (prefs.marketing) {
      console.log('Marketing cookies accepted');
      // Initialize marketing tools
    }
  };

  const handleAcceptAll = () => {
    saveConsent({
      essential: true,
      analytics: true,
      functional: true,
      marketing: true
    });
  };

  const handleRejectAll = () => {
    saveConsent({
      essential: true,
      analytics: false,
      functional: false,
      marketing: false
    });
  };

  const handleCustomize = () => {
    setShowBanner(false);
    setShowModal(true);
  };

  const handleSavePreferences = () => {
    saveConsent(preferences);
  };

  const handleCloseModal = () => {
    setShowModal(false);
    // If user closes modal without saving and hasn't consented yet, show banner again
    const hasConsent = localStorage.getItem(COOKIE_CONSENT_KEY);
    if (!hasConsent) {
      setShowBanner(true);
    }
  };

  // Render Arabic or English version based on language
  const Banner = isArabic ? CookieBannerAr : CookieBanner;
  const Modal = isArabic ? CookieModalAr : CookieModal;

  return (
    <>
      {showBanner && (
        <Banner
          onAcceptAll={handleAcceptAll}
          onRejectAll={handleRejectAll}
          onCustomize={handleCustomize}
          theme={currentTheme}
        />
      )}

      <Modal
        isOpen={showModal}
        onClose={handleCloseModal}
        preferences={preferences}
        onPreferencesChange={setPreferences}
        onSavePreferences={handleSavePreferences}
        onAcceptAll={handleAcceptAll}
        onRejectAll={handleRejectAll}
        theme={currentTheme}
      />
    </>
  );
}