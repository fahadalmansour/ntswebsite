import { CookieToggle } from './CookieToggle';

interface CookieCategoryRowArProps {
  title: string;
  description: string;
  checked: boolean;
  onChange?: (checked: boolean) => void;
  disabled?: boolean;
  theme?: 'light' | 'dark';
}

export function CookieCategoryRowAr({
  title,
  description,
  checked,
  onChange,
  disabled = false,
  theme = 'light'
}: CookieCategoryRowArProps) {
  const borderColor = theme === 'dark' ? 'border-slate-700' : 'border-slate-200';
  const titleColor = theme === 'dark' ? 'text-slate-100' : 'text-slate-900';
  const descriptionColor = theme === 'dark' ? 'text-slate-400' : 'text-slate-600';
  const labelColor = theme === 'dark' ? 'text-slate-500' : 'text-slate-500';

  return (
    <div className={`flex items-start justify-between gap-4 py-4 border-b ${borderColor} last:border-b-0`} dir="rtl">
      {/* Toggle on the right side for RTL */}
      <div className="flex-shrink-0 pt-1 order-2">
        <CookieToggle
          checked={checked}
          onChange={onChange}
          disabled={disabled}
          label={`تبديل ملفات تعريف الارتباط ${title}`}
          theme={theme}
        />
      </div>
      
      <div className="flex-1 min-w-0 order-1">
        <h3 className={`text-base font-semibold ${titleColor} mb-1`}>
          {title}
          {disabled && (
            <span className={`mr-2 text-xs font-normal ${labelColor}`}>(مفعّلة دائمًا)</span>
          )}
        </h3>
        <p className={`text-sm ${descriptionColor} leading-relaxed`}>
          {description}
        </p>
      </div>
    </div>
  );
}