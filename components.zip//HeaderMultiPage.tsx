import { useState, useEffect } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { routes, type Language } from '../utils/routes';

interface HeaderMultiPageProps {
  currentPage: string;
}

export function HeaderMultiPage({ currentPage }: HeaderMultiPageProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const { language, t } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const switchLanguage = (newLang: Language) => {
    const currentPath = window.location.pathname;
    const withoutLang = currentPath.replace(/^\/(en|ar)/, '');
    const newPath = `/${newLang}${withoutLang}`;
    window.location.href = newPath;
  };

  const navItems = [
    { id: 'how-we-work', label: t('nav.howWeWork'), hash: '#how-we-work' },
    { id: 'advisory-services', label: t('nav.consultingModels'), hash: '#advisory-services' },
    { id: 'what-you-receive', label: t('nav.deliverables'), hash: '#what-you-receive' },
    { id: 'contact', label: t('nav.contact'), href: routes.contact(language) }
  ];

  const handleNavClick = (item: typeof navItems[0]) => {
    if (item.href) {
      window.location.href = item.href;
    } else if (item.hash && currentPage === 'home') {
      const element = document.querySelector(item.hash);
      if (element) {
        const offset = 80;
        const elementPosition = element.getBoundingClientRect().top;
        const offsetPosition = elementPosition + window.pageYOffset - offset;
        window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
      }
    } else if (item.hash) {
      window.location.href = routes.home(language) + item.hash;
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-md shadow-sm' : 'bg-white/90 backdrop-blur-sm'
      }`}
    >
      <div className="max-w-[1100px] mx-auto px-6">
        <div className="flex justify-between items-center py-5">
          <a
            href={routes.home(language)}
            className="text-xl font-medium text-slate-900 hover:text-slate-700 transition-colors tracking-tight"
          >
            NeoTechnology Solutions
          </a>

          <div className="flex items-center gap-6">
            {/* Language Switcher */}
            <div className="flex items-center gap-2 border border-slate-200 rounded-full px-3 py-1.5">
              <button
                onClick={() => switchLanguage('en')}
                className={`text-sm px-2 py-1 rounded-full transition-all ${
                  language === 'en'
                    ? 'bg-slate-900 text-white font-medium'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => switchLanguage('ar')}
                className={`text-sm px-2 py-1 rounded-full transition-all ${
                  language === 'ar'
                    ? 'bg-slate-900 text-white font-medium'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                AR
              </button>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-6">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item)}
                  className="text-sm text-slate-600 hover:text-slate-900 transition-colors"
                >
                  {item.label}
                </button>
              ))}
              <a
                href={routes.contact(language)}
                className="px-5 py-2 bg-slate-900 text-white text-sm rounded-full hover:bg-slate-800 transition-all font-medium"
              >
                {t('nav.requestDiscussion')}
              </a>
            </nav>

            {/* Mobile CTA */}
            <a
              href={routes.contact(language)}
              className="lg:hidden px-5 py-2 bg-slate-900 text-white text-sm rounded-full hover:bg-slate-800 transition-all font-medium"
            >
              {t('nav.contact')}
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
