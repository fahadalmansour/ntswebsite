import { useLanguage } from '../contexts/LanguageContext';

export function AdvisoryServices() {
  const { t } = useLanguage();

  const directServices = [
    t('advisory.direct.item1'),
    t('advisory.direct.item2'),
    t('advisory.direct.item3'),
    t('advisory.direct.item4'),
    t('advisory.direct.item5')
  ];

  const vendorServices = [
    t('advisory.vendor.item1'),
    t('advisory.vendor.item2'),
    t('advisory.vendor.item3'),
    t('advisory.vendor.item4')
  ];

  return (
    <section id="advisory-services" className="py-16 px-6 bg-slate-50">
      <div className="max-w-[1100px] mx-auto">
        <div className="max-w-3xl mb-12">
          <h2 className="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
            {t('advisory.title')}
          </h2>
          <p className="text-xl text-slate-600 leading-relaxed">
            {t('advisory.subtitle')}
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Direct Advisory */}
          <div className="bg-white rounded-2xl p-10 border border-slate-200">
            <h3 className="text-2xl text-slate-900 mb-4 font-medium">
              {t('advisory.direct.title')}
            </h3>
            
            <p className="text-slate-600 leading-relaxed mb-8">
              {t('advisory.direct.desc')}
            </p>

            <ul className="space-y-3 mb-8">
              {directServices.map((service, index) => (
                <li key={index} className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 bg-slate-400 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-sm text-slate-700 leading-relaxed">{service}</span>
                </li>
              ))}
            </ul>

            <div className="pt-6 border-t border-slate-200">
              <p className="text-slate-900 font-medium mb-1">
                {t('advisory.direct.final')}
              </p>
              <p className="text-sm text-slate-600">
                {t('advisory.direct.output')}
              </p>
            </div>
          </div>

          {/* Vendor-Assisted Advisory */}
          <div className="bg-white rounded-2xl p-10 border border-slate-200">
            <h3 className="text-2xl text-slate-900 mb-4 font-medium">
              {t('advisory.vendor.title')}
            </h3>
            
            <p className="text-slate-600 leading-relaxed mb-8">
              {t('advisory.vendor.desc')}
            </p>

            <ul className="space-y-3 mb-8">
              {vendorServices.map((service, index) => (
                <li key={index} className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 bg-slate-400 rounded-full mt-2 flex-shrink-0"></div>
                  <span className="text-sm text-slate-700 leading-relaxed">{service}</span>
                </li>
              ))}
            </ul>

            <div className="pt-6 border-t border-slate-200 space-y-4">
              <p className="text-sm text-slate-600">
                {t('advisory.vendor.output')}
              </p>
              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                <p className="text-sm text-slate-700 leading-relaxed">
                  {t('advisory.vendor.note')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}