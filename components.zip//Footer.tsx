export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  return (
    <footer className="bg-slate-900 text-white py-12 px-6">
      <div className="max-w-[1100px] mx-auto">
        <div className="flex flex-col items-center gap-6 text-center">
          <div>
            <p className="text-lg font-medium mb-2">NeoTechnology Solutions LLC</p>
            <p className="text-sm text-slate-400">
              Independent IT decision advisory services
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-6 text-sm text-slate-400">
            <button className="hover:text-white transition-colors">
              Privacy
            </button>
            <span>•</span>
            <button className="hover:text-white transition-colors">
              Terms
            </button>
            <span>•</span>
            <button className="hover:text-white transition-colors">
              Disclosure
            </button>
            <span>•</span>
            <button
              onClick={scrollToTop}
              className="hover:text-white transition-colors"
            >
              Back to top ↑
            </button>
          </div>

          <div className="text-sm text-slate-500 pt-4 border-t border-slate-800 w-full">
            <p>© 2026 NeoTechnology Solutions LLC. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}