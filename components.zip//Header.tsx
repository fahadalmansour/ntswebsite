import { useState, useEffect } from 'react';

interface HeaderProps {
  activeSection: string;
}

export function Header({ activeSection }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const navItems = [
    { id: 'how-we-work', label: 'How we work' },
    { id: 'decision-areas', label: 'Decision Areas' },
    { id: 'what-you-receive', label: 'Deliverables' },
    { id: 'advisory-services', label: 'Services' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-md shadow-sm' : 'bg-white/90 backdrop-blur-sm'
      }`}
    >
      <div className="max-w-[1100px] mx-auto px-6">
        <div className="flex justify-between items-center py-5">
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="text-xl font-medium text-slate-900 hover:text-slate-700 transition-colors tracking-tight"
          >
            NeoTechnology Solutions
          </button>

          <nav className="hidden lg:flex items-center gap-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`text-sm transition-colors ${
                  activeSection === item.id
                    ? 'text-slate-900 font-medium'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => scrollToSection('contact')}
              className="px-5 py-2 bg-slate-900 text-white text-sm rounded-full hover:bg-slate-800 transition-all font-medium"
            >
              Request discussion
            </button>
          </nav>

          <button
            onClick={() => scrollToSection('contact')}
            className="lg:hidden px-5 py-2 bg-slate-900 text-white text-sm rounded-full hover:bg-slate-800 transition-all font-medium"
          >
            Contact
          </button>
        </div>
      </div>
    </header>
  );
}