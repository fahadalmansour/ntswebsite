import { useLanguage } from '../contexts/LanguageContext';

export function ToolsStandards() {
  const { t } = useLanguage();

  const categories = [
    {
      category: t('tools.cat1.title'),
      description: t('tools.cat1.desc')
    },
    {
      category: t('tools.cat2.title'),
      description: t('tools.cat2.desc')
    },
    {
      category: t('tools.cat3.title'),
      description: t('tools.cat3.desc')
    },
    {
      category: t('tools.cat4.title'),
      description: t('tools.cat4.desc')
    },
    {
      category: t('tools.cat5.title'),
      description: t('tools.cat5.desc')
    },
    {
      category: t('tools.cat6.title'),
      description: t('tools.cat6.desc')
    }
  ];

  return (
    <section id="tools-standards" className="py-16 px-6 bg-slate-50">
      <div className="max-w-[1100px] mx-auto">
        <div className="max-w-3xl mb-12">
          <h2 className="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
            {t('tools.title')}
          </h2>
          <p className="text-xl text-slate-600 leading-relaxed">
            {t('tools.subtitle')}
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((item, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-6 border border-slate-200"
            >
              <h3 className="text-slate-900 font-medium mb-2">
                {item.category}
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}