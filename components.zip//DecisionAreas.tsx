import { useLanguage } from '../contexts/LanguageContext';

export function DecisionAreas() {
  const { t } = useLanguage();

  const areas = [
    {
      title: t('decisionAreas.area1.title'),
      description: t('decisionAreas.area1.desc'),
      examples: [
        t('decisionAreas.area1.ex1'),
        t('decisionAreas.area1.ex2'),
        t('decisionAreas.area1.ex3')
      ]
    },
    {
      title: t('decisionAreas.area2.title'),
      description: t('decisionAreas.area2.desc'),
      examples: [
        t('decisionAreas.area2.ex1'),
        t('decisionAreas.area2.ex2'),
        t('decisionAreas.area2.ex3')
      ]
    },
    {
      title: t('decisionAreas.area3.title'),
      description: t('decisionAreas.area3.desc'),
      examples: [
        t('decisionAreas.area3.ex1'),
        t('decisionAreas.area3.ex2'),
        t('decisionAreas.area3.ex3')
      ]
    }
  ];

  return (
    <section id="decision-areas" className="py-16 px-6 bg-slate-50">
      <div className="max-w-[1100px] mx-auto">
        <div className="max-w-3xl mb-12">
          <h2 className="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
            {t('decisionAreas.title')}
          </h2>
          <p className="text-xl text-slate-600 leading-relaxed">
            {t('decisionAreas.subtitle')}
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {areas.map((area, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-8 border border-slate-200 hover:border-slate-300 transition-all"
            >
              <h3 className="text-xl text-slate-900 mb-4 font-medium">
                {area.title}
              </h3>
              <p className="text-slate-600 mb-6 leading-relaxed">
                {area.description}
              </p>
              <ul className="space-y-3">
                {area.examples.map((example, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="w-1 h-1 bg-slate-400 rounded-full mt-2.5 flex-shrink-0"></div>
                    <span className="text-sm text-slate-600 leading-relaxed">{example}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}