import { useLanguage } from '../contexts/LanguageContext';

export function Engagement() {
  const { t } = useLanguage();

  return (
    <section id="engagement" className="py-16 px-6 bg-slate-50">
      <div className="max-w-[1100px] mx-auto">
        <div className="max-w-3xl mb-12">
          <h2 className="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
            {t('engagement.title')}
          </h2>
          <p className="text-xl text-slate-600 leading-relaxed">
            {t('engagement.subtitle')}
          </p>
        </div>

        <div className="grid sm:grid-cols-3 gap-6 mb-10">
          <div className="bg-white rounded-xl p-8 border border-slate-200 text-center">
            <p className="text-lg text-slate-900 font-medium">{t('engagement.fixed')}</p>
          </div>
          <div className="bg-white rounded-xl p-8 border border-slate-200 text-center">
            <p className="text-lg text-slate-900 font-medium">{t('engagement.documented')}</p>
          </div>
          <div className="bg-white rounded-xl p-8 border border-slate-200 text-center">
            <p className="text-lg text-slate-900 font-medium">{t('engagement.contractual')}</p>
          </div>
        </div>

        <div className="max-w-3xl mx-auto bg-white rounded-2xl p-10 border border-slate-200">
          <p className="text-slate-700 leading-relaxed text-center text-lg">
            {t('engagement.responsibility')}
          </p>
        </div>
      </div>
    </section>
  );
}