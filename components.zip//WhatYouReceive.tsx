import { useLanguage } from '../contexts/LanguageContext';

export function WhatYouReceive() {
  const { t } = useLanguage();

  const deliverables = [
    {
      title: t('receive.item1.title'),
      description: t('receive.item1.desc')
    },
    {
      title: t('receive.item2.title'),
      description: t('receive.item2.desc')
    },
    {
      title: t('receive.item3.title'),
      description: t('receive.item3.desc')
    },
    {
      title: t('receive.item4.title'),
      description: t('receive.item4.desc')
    },
    {
      title: t('receive.item5.title'),
      description: t('receive.item5.desc')
    }
  ];

  return (
    <section id="what-you-receive" className="py-16 px-6 bg-white">
      <div className="max-w-[1100px] mx-auto">
        <div className="max-w-3xl mb-12">
          <h2 className="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
            {t('receive.title')}
          </h2>
          <p className="text-xl text-slate-600 leading-relaxed">
            {t('receive.subtitle')}
          </p>
        </div>

        <div className="space-y-3">
          {deliverables.map((item, index) => (
            <div
              key={index}
              className="bg-slate-50 rounded-xl p-6 border border-slate-200 hover:border-slate-300 transition-all"
            >
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-slate-900 text-white rounded-lg flex items-center justify-center text-sm font-medium">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <h3 className="text-slate-900 font-medium mb-1">
                    {item.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}