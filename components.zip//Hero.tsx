import { Check } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function Hero() {
  const { t } = useLanguage();
  
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section className="pt-32 pb-20 px-6 bg-white">
      <div className="max-w-[1100px] mx-auto">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h1 className="text-5xl sm:text-6xl lg:text-7xl text-slate-900 mb-6 leading-[1.1] tracking-tight font-light">
            {t('hero.title')}
          </h1>
          
          <p className="text-xl sm:text-2xl text-slate-600 mb-12 font-normal max-w-2xl mx-auto leading-relaxed">
            {t('hero.subtitle')}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <button
              onClick={() => scrollToSection('contact')}
              className="px-8 py-4 bg-slate-900 text-white rounded-full hover:bg-slate-800 transition-all text-base font-medium"
            >
              {t('hero.requestDiscussion')}
            </button>
            <button
              onClick={() => scrollToSection('how-we-work')}
              className="px-8 py-4 bg-white text-slate-900 border border-slate-300 rounded-full hover:border-slate-400 hover:bg-slate-50 transition-all text-base font-medium"
            >
              {t('hero.howWeWork')}
            </button>
          </div>
        </div>

        {/* Trust principles */}
        <div className="grid sm:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <div className="text-center">
            <p className="text-slate-900 font-medium mb-2">{t('hero.noSelling')}</p>
            <p className="text-sm text-slate-600 leading-relaxed">
              {t('hero.noSellingDesc')}
            </p>
          </div>
          <div className="text-center">
            <p className="text-slate-900 font-medium mb-2">{t('hero.noImplementation')}</p>
            <p className="text-sm text-slate-600 leading-relaxed">
              {t('hero.noImplementationDesc')}
            </p>
          </div>
          <div className="text-center">
            <p className="text-slate-900 font-medium mb-2">{t('hero.clientDecides')}</p>
            <p className="text-sm text-slate-600 leading-relaxed">
              {t('hero.clientDecidesDesc')}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}