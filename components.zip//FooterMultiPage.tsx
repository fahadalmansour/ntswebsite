import { useLanguage } from '../contexts/LanguageContext';
import { routes } from '../utils/routes';

export function FooterMultiPage() {
  const { language, t } = useLanguage();

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const legalLinks = [
    { label: t('footer.privacy'), href: routes.privacy(language) },
    { label: t('footer.cookies'), href: routes.cookies(language) },
    { label: t('footer.terms'), href: routes.terms(language) },
    { label: t('footer.disclaimer'), href: routes.disclaimer(language) },
    { label: t('footer.disclosure'), href: routes.disclosure(language) },
    { label: t('footer.contact'), href: routes.contact(language) }
  ];

  return (
    <footer className="bg-slate-900 text-white py-12 px-6">
      <div className="max-w-[1100px] mx-auto">
        <div className="flex flex-col items-center gap-6 text-center">
          <div>
            <p className="text-lg font-medium mb-2">{t('footer.company')}</p>
            <p className="text-sm text-slate-400">
              {t('footer.tagline')}
            </p>
          </div>

          <div className="flex flex-wrap justify-center gap-4 text-sm text-slate-400">
            {legalLinks.map((link, index) => (
              <div key={link.href} className="flex items-center gap-4">
                <a
                  href={link.href}
                  className="hover:text-white transition-colors"
                >
                  {link.label}
                </a>
                {index < legalLinks.length - 1 && <span>•</span>}
              </div>
            ))}
          </div>

          <button
            onClick={scrollToTop}
            className="text-sm text-slate-400 hover:text-white transition-colors"
          >
            {t('footer.backToTop')}
          </button>

          <div className="text-sm text-slate-500 pt-4 border-t border-slate-800 w-full">
            <p>{t('footer.rights')}</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
