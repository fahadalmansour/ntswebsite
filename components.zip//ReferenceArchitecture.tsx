import { ArrowRight, ArrowLeft } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function ReferenceArchitecture() {
  const { t, language } = useLanguage();
  const isRTL = language === 'ar';
  
  const layers = [
    t('refArch.layer1'),
    t('refArch.layer2'),
    t('refArch.layer3'),
    t('refArch.layer4'),
    t('refArch.layer5'),
    t('refArch.layer6')
  ];

  return (
    <section id="reference-architecture" className="py-16 px-6 bg-white">
      <div className="max-w-[1100px] mx-auto">
        <div className="max-w-3xl mb-12">
          <h2 className="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
            {t('refArch.title')}
          </h2>
          <p className="text-xl text-slate-600 leading-relaxed">
            {t('refArch.subtitle')}
          </p>
        </div>

        <div className="bg-slate-50 rounded-3xl p-8 sm:p-10 border border-slate-200">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            {layers.map((layer, index) => (
              <div key={index} className="flex items-center gap-6 w-full lg:w-auto">
                <div className="flex-1 lg:flex-initial">
                  <div className="bg-white rounded-xl px-6 py-5 border border-slate-200 text-center min-w-[140px] hover:border-slate-300 transition-all">
                    <p className="text-slate-900 font-medium text-sm whitespace-nowrap">
                      {layer}
                    </p>
                  </div>
                </div>
                {index < layers.length - 1 && (
                  isRTL ? (
                    <ArrowLeft className="hidden lg:block w-5 h-5 text-slate-400 flex-shrink-0" />
                  ) : (
                    <ArrowRight className="hidden lg:block w-5 h-5 text-slate-400 flex-shrink-0" />
                  )
                )}
              </div>
            ))}
          </div>
          
          <div className="mt-8 pt-8 border-t border-slate-200">
            <p className="text-sm text-slate-600 text-center leading-relaxed">
              {t('refArch.note')}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}