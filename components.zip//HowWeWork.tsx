import { useLanguage } from '../contexts/LanguageContext';

export function HowWeWork() {
  const { t } = useLanguage();

  const steps = [
    {
      number: '01',
      title: t('howWeWork.step1.title'),
      description: t('howWeWork.step1.desc')
    },
    {
      number: '02',
      title: t('howWeWork.step2.title'),
      description: t('howWeWork.step2.desc')
    },
    {
      number: '03',
      title: t('howWeWork.step3.title'),
      description: t('howWeWork.step3.desc')
    },
    {
      number: '04',
      title: t('howWeWork.step4.title'),
      description: t('howWeWork.step4.desc')
    }
  ];

  return (
    <section id="how-we-work" className="py-16 px-6 bg-white">
      <div className="max-w-[1100px] mx-auto">
        <div className="max-w-3xl mb-12">
          <h2 className="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
            {t('howWeWork.title')}
          </h2>
          <p className="text-xl text-slate-600 leading-relaxed">
            {t('howWeWork.subtitle')}
          </p>
        </div>

        <div className="space-y-4">
          {steps.map((step, index) => (
            <div
              key={index}
              className="bg-slate-50 rounded-2xl p-8 border border-slate-200 hover:border-slate-300 transition-all"
            >
              <div className="flex items-start gap-6">
                <div className="text-3xl font-light text-slate-400">
                  {step.number}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl text-slate-900 mb-2 font-medium">
                    {step.title}
                  </h3>
                  <p className="text-slate-600 leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}