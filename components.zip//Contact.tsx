import { useState } from 'react';
import { Mail, Check } from 'lucide-react';

export function Contact() {
  const [formData, setFormData] = useState({
    companyName: '',
    yourName: '',
    email: '',
    phone: '',
    decisionType: '',
    description: '',
    consent: false
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitted, setIsSubmitted] = useState(false);

  const decisionTypes = [
    'Cloud vs On-Prem/Hybrid',
    'Vendor/Scope selection',
    'Scale vs Stability',
    'Other'
  ];

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.companyName.trim()) {
      newErrors.companyName = 'Company name is required';
    }
    if (!formData.yourName.trim()) {
      newErrors.yourName = 'Your name is required';
    }
    if (!formData.email.trim()) {
      newErrors.email = 'Business email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    if (!formData.decisionType) {
      newErrors.decisionType = 'Please select a decision type';
    }
    if (!formData.description.trim()) {
      newErrors.description = 'Description is required';
    }
    if (!formData.consent) {
      newErrors.consent = 'You must confirm understanding of advisory-only nature';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (validateForm()) {
      // Create mailto link with form data
      const subject = encodeURIComponent(`Advisory Request: ${formData.decisionType}`);
      const body = encodeURIComponent(
        `Company: ${formData.companyName}\n` +
        `Name: ${formData.yourName}\n` +
        `Email: ${formData.email}\n` +
        `Phone: ${formData.phone || 'Not provided'}\n` +
        `Decision Type: ${formData.decisionType}\n\n` +
        `Description:\n${formData.description}\n\n` +
        `Advisory-only confirmation: Yes`
      );

      const mailtoLink = `mailto:contact@neotechnology.solutions?subject=${subject}&body=${body}`;
      
      // Open mailto link
      window.location.href = mailtoLink;
      
      // Show success message
      setIsSubmitted(true);
      
      // Reset form after 3 seconds
      setTimeout(() => {
        setFormData({
          companyName: '',
          yourName: '',
          email: '',
          phone: '',
          decisionType: '',
          description: '',
          consent: false
        });
        setIsSubmitted(false);
      }, 3000);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value, type } = e.target;
    const checked = (e.target as HTMLInputElement).checked;

    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));

    // Clear error for this field when user starts typing
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  if (isSubmitted) {
    return (
      <section id="contact" className="py-16 px-6 bg-white">
        <div className="max-w-2xl mx-auto">
          <div className="bg-slate-50 rounded-3xl p-10 text-center border border-slate-200">
            <div className="w-16 h-16 bg-slate-900 rounded-full flex items-center justify-center mx-auto mb-6">
              <Check className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl text-slate-900 mb-4 font-medium">
              Request submitted
            </h3>
            <p className="text-slate-700 mb-4 leading-relaxed">
              Your email client should open with a pre-filled message. Please review and send it to complete your request.
            </p>
            <p className="text-sm text-slate-600">
              If your email client didn't open, please contact us directly at{' '}
              <a href="mailto:contact@neotechnology.solutions" className="text-slate-900 underline font-medium">
                contact@neotechnology.solutions
              </a>
            </p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="contact" className="py-16 px-6 bg-white">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
            Request an initial discussion
          </h2>
          <p className="text-xl text-slate-700 mb-4 leading-relaxed">
            If your business needs to make an IT decision and wants structured, honest guidance, 
            request an initial discussion.
          </p>
          <p className="text-sm text-slate-600">
            We reply within 1 business day.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="bg-slate-50 rounded-3xl p-8 border border-slate-200">
          <div className="space-y-6">
            {/* Company Name */}
            <div>
              <label htmlFor="companyName" className="block text-sm font-medium text-slate-900 mb-2">
                Company name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="companyName"
                name="companyName"
                value={formData.companyName}
                onChange={handleChange}
                className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-slate-900 ${
                  errors.companyName ? 'border-red-500' : 'border-slate-300'
                }`}
              />
              {errors.companyName && (
                <p className="mt-1 text-sm text-red-500">{errors.companyName}</p>
              )}
            </div>

            {/* Your Name */}
            <div>
              <label htmlFor="yourName" className="block text-sm font-medium text-slate-900 mb-2">
                Your name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="yourName"
                name="yourName"
                value={formData.yourName}
                onChange={handleChange}
                className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-slate-900 ${
                  errors.yourName ? 'border-red-500' : 'border-slate-300'
                }`}
              />
              {errors.yourName && (
                <p className="mt-1 text-sm text-red-500">{errors.yourName}</p>
              )}
            </div>

            {/* Business Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-slate-900 mb-2">
                Business email <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-slate-900 ${
                  errors.email ? 'border-red-500' : 'border-slate-300'
                }`}
              />
              {errors.email && (
                <p className="mt-1 text-sm text-red-500">{errors.email}</p>
              )}
            </div>

            {/* Phone */}
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-slate-900 mb-2">
                Phone <span className="text-slate-500">(optional)</span>
              </label>
              <input
                type="tel"
                id="phone"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                className="w-full px-4 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>

            {/* Decision Type */}
            <div>
              <label htmlFor="decisionType" className="block text-sm font-medium text-slate-900 mb-2">
                Decision type <span className="text-red-500">*</span>
              </label>
              <select
                id="decisionType"
                name="decisionType"
                value={formData.decisionType}
                onChange={handleChange}
                className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-slate-900 ${
                  errors.decisionType ? 'border-red-500' : 'border-slate-300'
                }`}
              >
                <option value="">Select a decision type</option>
                {decisionTypes.map((type) => (
                  <option key={type} value={type}>
                    {type}
                  </option>
                ))}
              </select>
              {errors.decisionType && (
                <p className="mt-1 text-sm text-red-500">{errors.decisionType}</p>
              )}
            </div>

            {/* Description */}
            <div>
              <label htmlFor="description" className="block text-sm font-medium text-slate-900 mb-2">
                Short description <span className="text-red-500">*</span>
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={4}
                className={`w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-slate-900 ${
                  errors.description ? 'border-red-500' : 'border-slate-300'
                }`}
              />
              {errors.description && (
                <p className="mt-1 text-sm text-red-500">{errors.description}</p>
              )}
            </div>

            {/* Consent Checkbox */}
            <div>
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  name="consent"
                  checked={formData.consent}
                  onChange={handleChange}
                  className="mt-1 w-4 h-4 text-slate-900 border-slate-300 rounded focus:ring-2 focus:ring-slate-900"
                />
                <span className="text-sm text-slate-700">
                  I understand this is advisory only (not implementation). <span className="text-red-500">*</span>
                </span>
              </label>
              {errors.consent && (
                <p className="mt-1 text-sm text-red-500">{errors.consent}</p>
              )}
            </div>

            {/* Submit Button */}
            <div className="pt-6">
              <button
                type="submit"
                className="w-full px-8 py-4 bg-slate-900 text-white rounded-xl hover:bg-slate-800 transition-all shadow-sm hover:shadow-md flex items-center justify-center gap-2 font-medium text-lg"
              >
                <Mail className="w-5 h-5" />
                Send request
              </button>
            </div>
          </div>
        </form>
      </div>
    </section>
  );
}