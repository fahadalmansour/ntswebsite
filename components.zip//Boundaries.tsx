import { useLanguage } from '../contexts/LanguageContext';

export function Boundaries() {
  const { t } = useLanguage();

  const exclusions = [
    t('boundaries.item1'),
    t('boundaries.item2'),
    t('boundaries.item3'),
    t('boundaries.item4')
  ];

  return (
    <section id="boundaries" className="py-16 px-6 bg-white">
      <div className="max-w-[1100px] mx-auto">
        <div className="max-w-3xl mb-12">
          <h2 className="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
            {t('boundaries.title')}
          </h2>
          <p className="text-xl text-slate-600 leading-relaxed">
            {t('boundaries.subtitle')}
          </p>
        </div>

        <div className="bg-slate-50 rounded-2xl p-8 border border-slate-200">
          <ul className="grid sm:grid-cols-2 gap-4">
            {exclusions.map((exclusion, index) => (
              <li key={index} className="flex items-start gap-3 text-slate-700 leading-relaxed">
                <div className="w-1.5 h-1.5 bg-slate-400 rounded-full mt-2 flex-shrink-0"></div>
                <span>{exclusion}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}