import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    // Check URL path for language
    const path = window.location.pathname;
    if (path.startsWith('/ar')) {
      setLanguage('ar');
      document.documentElement.dir = 'rtl';
      document.documentElement.lang = 'ar';
    } else {
      setLanguage('en');
      document.documentElement.dir = 'ltr';
      document.documentElement.lang = 'en';
    }
  }, []);

  const t = (key: string) => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navigation
    'nav.howWeWork': 'How we work',
    'nav.consultingModels': 'Consulting Models',
    'nav.deliverables': 'Deliverables',
    'nav.contact': 'Contact',
    'nav.requestDiscussion': 'Request discussion',
    
    // Footer
    'footer.privacy': 'Privacy Policy',
    'footer.cookies': 'Cookie Policy',
    'footer.terms': 'Terms of Use',
    'footer.disclaimer': 'Advisory Disclaimer',
    'footer.disclosure': 'Disclosure Policy',
    'footer.contact': 'Contact',
    'footer.company': 'NeoTechnology Solutions LLC',
    'footer.tagline': 'Independent IT decision advisory services',
    'footer.rights': '© 2026 NeoTechnology Solutions LLC. All rights reserved.',
    'footer.backToTop': 'Back to top ↑',
    
    // Hero
    'hero.title': 'Independent IT Decision Advisory',
    'hero.subtitle': 'Structured guidance for operational businesses making critical IT and system decisions.',
    'hero.requestDiscussion': 'Request initial discussion',
    'hero.howWeWork': 'How we work',
    'hero.noSelling': 'No selling',
    'hero.noSellingDesc': 'We do not sell software or hardware',
    'hero.noImplementation': 'No implementation',
    'hero.noImplementationDesc': 'We do not implement or manage systems',
    'hero.clientDecides': 'Client decides',
    'hero.clientDecidesDesc': 'Final decisions are always made by the client',

    // How We Work
    'howWeWork.title': 'How we work',
    'howWeWork.subtitle': 'A structured, repeatable approach to clarifying complex IT decisions.',
    'howWeWork.step1.title': 'Context & constraints',
    'howWeWork.step1.desc': 'Understanding your operational environment, requirements, and decision timeline',
    'howWeWork.step2.title': 'Options A/B/C',
    'howWeWork.step2.desc': 'Presenting structured alternatives based on your specific situation',
    'howWeWork.step3.title': 'Trade-offs documented',
    'howWeWork.step3.desc': 'Clear analysis of implications, risks, and operational impact for each option',
    'howWeWork.step4.title': 'Decision summary delivered',
    'howWeWork.step4.desc': 'Structured documentation to support your final decision and next steps',

    // Decision Areas
    'decisionAreas.title': 'Decision Areas',
    'decisionAreas.subtitle': 'We guide businesses through complex IT decisions across three core areas.',
    'decisionAreas.area1.title': 'Cloud vs On-Prem/Hybrid',
    'decisionAreas.area1.desc': 'Evaluate operational fit, risk profile, and long-term flexibility.',
    'decisionAreas.area1.ex1': 'Workload placement and data residency',
    'decisionAreas.area1.ex2': 'Cost modeling across scenarios',
    'decisionAreas.area1.ex3': 'Vendor lock-in and exit strategy',
    'decisionAreas.area2.title': 'Vendor & Scope Selection',
    'decisionAreas.area2.desc': 'Compare options and clarify what each party owns and delivers.',
    'decisionAreas.area2.ex1': 'Capability gaps and integration requirements',
    'decisionAreas.area2.ex2': 'Support SLAs and escalation paths',
    'decisionAreas.area2.ex3': 'Contract terms and pricing structures',
    'decisionAreas.area3.title': 'Scale vs Stability',
    'decisionAreas.area3.desc': 'Balance growth needs with operational reliability and team capacity.',
    'decisionAreas.area3.ex1': 'Technical debt and refactoring priorities',
    'decisionAreas.area3.ex2': 'Team skills and external dependencies',
    'decisionAreas.area3.ex3': 'Monitoring, alerting, and incident response',

    // Reference Architecture
    'refArch.title': 'Reference Architecture',
    'refArch.subtitle': 'We help you think through the full stack—from user access to data protection and monitoring.',
    'refArch.layer1': 'Users/Branches',
    'refArch.layer2': 'Identity & Access',
    'refArch.layer3': 'Network',
    'refArch.layer4': 'Apps',
    'refArch.layer5': 'Data',
    'refArch.layer6': 'Monitoring/Backups',
    'refArch.note': 'High-level view only. We document responsibilities, integration points, and decision boundaries for each layer.',

    // Tools & Standards
    'tools.title': 'Tools & Standards',
    'tools.subtitle': 'We help clarify requirements across operational and security categories—without pushing specific vendors.',
    'tools.cat1.title': 'SSO/MFA',
    'tools.cat1.desc': 'Identity federation, multi-factor authentication, directory integration',
    'tools.cat2.title': 'Monitoring',
    'tools.cat2.desc': 'Infrastructure metrics, application logs, alerting thresholds',
    'tools.cat3.title': 'Backups (RPO/RTO)',
    'tools.cat3.desc': 'Recovery point objectives, restore time targets, testing cadence',
    'tools.cat4.title': 'Security Baseline',
    'tools.cat4.desc': 'Patching, hardening, vulnerability scanning, access controls',
    'tools.cat5.title': 'Cloud Cost Controls',
    'tools.cat5.desc': 'Budget alerts, resource tagging, usage optimization, forecasting',
    'tools.cat6.title': 'Network & Connectivity',
    'tools.cat6.desc': 'VPN, direct connect, segmentation, firewall rules, DNS',

    // What You Receive
    'receive.title': 'What you receive',
    'receive.subtitle': 'Structured deliverables designed to support your decision-making and handoff to implementation teams.',
    'receive.item1.title': 'Decision summary PDF',
    'receive.item1.desc': 'Comprehensive documentation of context, options, and recommendations',
    'receive.item2.title': 'A/B/C comparison',
    'receive.item2.desc': 'Structured analysis of alternatives with trade-offs clearly outlined',
    'receive.item3.title': 'Scope map',
    'receive.item3.desc': 'Clear definition of responsibilities, boundaries, and handoff points',
    'receive.item4.title': 'Vendor questions checklist',
    'receive.item4.desc': 'Structured questions to clarify proposals and expectations',
    'receive.item5.title': 'High-level architecture notes (1 page)',
    'receive.item5.desc': 'Reference diagram and integration points for technical alignment',

    // Advisory Services
    'advisory.title': 'Advisory Services',
    'advisory.subtitle': 'Two engagement models to match your situation.',
    'advisory.direct.title': 'Direct Decision Advisory',
    'advisory.direct.desc': 'We work directly with your team to provide structured, neutral guidance for IT decisions.',
    'advisory.direct.item1': 'Cloud vs on-prem vs hybrid decisions',
    'advisory.direct.item2': 'Platform and vendor comparison',
    'advisory.direct.item3': 'Operational impact and risk analysis',
    'advisory.direct.item4': 'Clarifying scope, responsibilities, expectations',
    'advisory.direct.item5': 'Presenting structured options (A/B/C) based on context',
    'advisory.direct.final': 'The business makes the final decision.',
    'advisory.direct.output': 'Typical output: Decision summary + next steps',
    'advisory.vendor.title': 'Vendor-Assisted Decision Advisory',
    'advisory.vendor.desc': 'When vendors or integrators are involved, we act as a neutral advisor to ensure clarity on scope and expectations.',
    'advisory.vendor.item1': 'Proposal review and gap analysis',
    'advisory.vendor.item2': 'Scope and responsibilities defined',
    'advisory.vendor.item3': 'Expectations documented',
    'advisory.vendor.item4': 'Decision mapping and handoff clarity',
    'advisory.vendor.output': 'Typical output: Decision summary + next steps',
    'advisory.vendor.note': 'Any commissions or referral fees are fully disclosed and documented in advance.',

    // Boundaries
    'boundaries.title': 'What we do not do',
    'boundaries.subtitle': 'Our role is advisory and decision-focused only.',
    'boundaries.item1': 'Ongoing IT support or system administration',
    'boundaries.item2': 'Software development or system implementation',
    'boundaries.item3': 'Managed services or operational ownership',
    'boundaries.item4': 'Outcome or performance guarantees',

    // Engagement
    'engagement.title': 'Engagement structure',
    'engagement.subtitle': 'Professional, transparent, and accountable.',
    'engagement.fixed': 'Fixed-scope',
    'engagement.documented': 'Documented',
    'engagement.contractual': 'Contractual',
    'engagement.responsibility': 'Our responsibility is to explain options and implications clearly. The client is responsible for the final decision and execution.'
  },
  ar: {
    // Navigation
    'nav.howWeWork': 'كيف نعمل',
    'nav.consultingModels': 'نماذج الاستشارات',
    'nav.deliverables': 'المخرجات',
    'nav.contact': 'تواصل معنا',
    'nav.requestDiscussion': 'طلب جلسة',
    
    // Footer
    'footer.privacy': 'سياسة الخصوصية',
    'footer.cookies': 'سياسة ملفات الارتباط',
    'footer.terms': 'شروط الاستخدام',
    'footer.disclaimer': 'إخلاء المسؤولية',
    'footer.disclosure': 'سياسة الإفصاح',
    'footer.contact': 'تواصل معنا',
    'footer.company': 'شركة نيوتكنولوجي سوليوشنز ذ.م.م',
    'footer.tagline': 'خدمات استشارية مستقلة لقرارات تقنية المعلومات',
    'footer.rights': '© 2026 شركة نيوتكنولوجي سوليوشنز ذ.م.م. جميع الحقوق محفوظة.',
    'footer.backToTop': 'العودة للأعلى ↑',
    
    // Hero
    'hero.title': 'استشارات مستقلة لقرارات تقنية المعلومات',
    'hero.subtitle': 'توجيه منظم للشركات التشغيلية في اتخاذ قرارات تقنية المعلومات والأنظمة الحرجة.',
    'hero.requestDiscussion': 'طلب جلسة استشارية',
    'hero.howWeWork': 'كيف نعمل',
    'hero.noSelling': 'لا نبيع',
    'hero.noSellingDesc': 'نحن لا نبيع برامج أو أجهزة',
    'hero.noImplementation': 'لا ننفذ',
    'hero.noImplementationDesc': 'نحن لا ننفذ أو ندير الأنظمة',
    'hero.clientDecides': 'العميل يقرر',
    'hero.clientDecidesDesc': 'القرارات النهائية دائماً من مسؤولية العميل',

    // How We Work
    'howWeWork.title': 'كيف نعمل',
    'howWeWork.subtitle': 'نهج منظم وقابل للتكرار لتوضيح القرارات التقنية المعقدة.',
    'howWeWork.step1.title': 'السياق والقيود',
    'howWeWork.step1.desc': 'فهم بيئة العمل التشغيلية والمتطلبات والجدول الزمني لاتخاذ القرار',
    'howWeWork.step2.title': 'الخيارات أ/ب/ج',
    'howWeWork.step2.desc': 'تقديم بدائل منظمة بناءً على وضعك المحدد',
    'howWeWork.step3.title': 'توثيق المفاضلات',
    'howWeWork.step3.desc': 'تحليل واضح للتداعيات والمخاطر والتأثير التشغيلي لكل خيار',
    'howWeWork.step4.title': 'تسليم ملخص القرار',
    'howWeWork.step4.desc': 'وثائق منظمة لدعم قرارك النهائي والخطوات التالية',

    // Decision Areas
    'decisionAreas.title': 'مجالات القرار',
    'decisionAreas.subtitle': 'نوجه الشركات خلال القرارات التقنية المعقدة عبر ثلاثة مجالات أساسية.',
    'decisionAreas.area1.title': 'السحابية مقابل المحلية/الهجينة',
    'decisionAreas.area1.desc': 'تقييم التوافق التشغيلي، ملف المخاطر، والمرونة طويلة الأمد.',
    'decisionAreas.area1.ex1': 'موقع تشغيل الأنظمة ومحل إقامة البيانات',
    'decisionAreas.area1.ex2': 'نمذجة التكلفة عبر السيناريوهات المختلفة',
    'decisionAreas.area1.ex3': 'التقيد بالمورد واستراتيجية الخروج',
    'decisionAreas.area2.title': 'اختيار المورد والنطاق',
    'decisionAreas.area2.desc': 'مقارنة الخيارات وتوضيح ما يمتلكه ويقدمه كل طرف.',
    'decisionAreas.area2.ex1': 'فجوات القدرات ومتطلبات التكامل',
    'decisionAreas.area2.ex2': 'اتفاقيات مستوى الخدمة (SLA) ومسارات التصعيد',
    'decisionAreas.area2.ex3': 'شروط العقد وهياكل التسعير',
    'decisionAreas.area3.title': 'النطاق مقابل الاستقرار',
    'decisionAreas.area3.desc': 'الموازنة بين احتياجات النمو والموثوقية التشغيلية وقدرة الفريق.',
    'decisionAreas.area3.ex1': 'الديون التقنية وأولويات إعادة الهيكلة',
    'decisionAreas.area3.ex2': 'مهارات الفريق والاعتمادات الخارجية',
    'decisionAreas.area3.ex3': 'المراقبة والتنبيه والاستجابة للحوادث',

    // Reference Architecture
    'refArch.title': 'الهندسة المرجعية',
    'refArch.subtitle': 'نساعدك في التفكير عبر كامل النطاق التقني - من وصول المستخدم إلى حماية البيانات والمراقبة.',
    'refArch.layer1': 'المستخدمون/الفروع',
    'refArch.layer2': 'الهوية والوصول',
    'refArch.layer3': 'الشبكة',
    'refArch.layer4': 'التطبيقات',
    'refArch.layer5': 'البيانات',
    'refArch.layer6': 'المراقبة/النسخ الاحتياطي',
    'refArch.note': 'نظرة عامة عالية المستوى فقط. نحن نوثق المسؤوليات ونقاط التكامل وحدود القرار لكل طبقة.',

    // Tools & Standards
    'tools.title': 'الأدوات والمعايير',
    'tools.subtitle': 'نساعد في توضيح المتطلبات عبر الفئات التشغيلية والأمنية - دون الدفع نحو موردين محددين.',
    'tools.cat1.title': 'الدخول الموحد/المصادقة المتعددة',
    'tools.cat1.desc': 'اتحاد الهو��ة، المصادقة متعددة العوامل، تكامل الدليل',
    'tools.cat2.title': 'المراقبة',
    'tools.cat2.desc': 'مقاييس البنية التحتية، سجلات التطبيقات، عتبات التنبيه',
    'tools.cat3.title': 'النسخ الاحتياطي (RPO/RTO)',
    'tools.cat3.desc': 'أهداف نقطة الاسترداد، أهداف وقت الاستعادة، وتيرة الاختبار',
    'tools.cat4.title': 'الأساس الأمني',
    'tools.cat4.desc': 'التحديثات، التصليب، فحص الثغرات، ضوابط الوصول',
    'tools.cat5.title': 'ضوابط التكلفة السحابية',
    'tools.cat5.desc': 'تنبيهات الميزانية، وسم الموارد، تحسين الاستخدام، التنبؤ',
    'tools.cat6.title': 'الشبكة والاتصال',
    'tools.cat6.desc': 'VPN، الاتصال المباشر، التجزئة، قواعد جدار الحماية، DNS',

    // What You Receive
    'receive.title': 'ماذا تتلقى',
    'receive.subtitle': 'مخرجات منظمة مصممة لدعم اتخاذ القرار وتسليم المهام لفرق التنفيذ.',
    'receive.item1.title': 'ملخص القرار (PDF)',
    'receive.item1.desc': 'وثائق شاملة للسياق والخيارات والتوصيات',
    'receive.item2.title': 'مقارنة أ/ب/ج',
    'receive.item2.desc': 'تحليل منظم للبدائل مع توضيح المفاضلات بوضوح',
    'receive.item3.title': 'خريطة النطاق',
    'receive.item3.desc': 'تعريف واضح للمسؤوليات والحدود ونقاط التسليم',
    'receive.item4.title': 'قائمة أسئلة الموردين',
    'receive.item4.desc': 'أسئلة منظمة لتوضيح العروض والتوقعات',
    'receive.item5.title': 'ملاحظات الهندسة العامة (صفحة واحدة)',
    'receive.item5.desc': 'مخطط مرجعي ونقاط التكامل للمواءمة الفنية',

    // Advisory Services
    'advisory.title': 'الخدمات الاستشارية',
    'advisory.subtitle': 'نموذجان للمشاركة لتناسب وضعك.',
    'advisory.direct.title': 'استشارات القرار المباشر',
    'advisory.direct.desc': 'نعمل مباشرة مع فريقك لتقديم توجيه منظم ومحايد لقرارات تقنية المعلومات.',
    'advisory.direct.item1': 'قرارات السحابة مقابل المحلي مقابل الهجين',
    'advisory.direct.item2': 'مقارنة المنصات والموردين',
    'advisory.direct.item3': 'تحليل التأثير التشغيلي والمخاطر',
    'advisory.direct.item4': 'توضيح النطاق والمسؤ��ليات والتوقعات',
    'advisory.direct.item5': 'تقديم خيارات منظمة (أ/ب/ج) بناءً على السياق',
    'advisory.direct.final': 'العمل يتخذ القرار النهائي.',
    'advisory.direct.output': 'المخرج النموذجي: ملخص القرار + الخطوات التالية',
    'advisory.vendor.title': 'استشارات القرار بمساعدة المورد',
    'advisory.vendor.desc': 'عند مشاركة الموردين أو المنفذين، نعمل كمستشار محايد لضمان وضوح النطاق والتوقعات.',
    'advisory.vendor.item1': 'مراجعة العروض وتحليل الفجوات',
    'advisory.vendor.item2': 'تحديد النطاق والمسؤوليات',
    'advisory.vendor.item3': 'توثيق التوقعات',
    'advisory.vendor.item4': 'رسم خرائط القرار ووضوح التسليم',
    'advisory.vendor.output': 'المخرج النموذجي: ملخص القرار + الخطوات التالية',
    'advisory.vendor.note': 'يتم الإفصاح الكامل عن أي عمولات أو رسوم إحالة وتوثيقها مسبقاً.',

    // Boundaries
    'boundaries.title': 'ما لا نقوم به',
    'boundaries.subtitle': 'دورنا استشاري ومركز على اتخاذ القرار فقط.',
    'boundaries.item1': 'دعم تقني مستمر أو إدارة أنظمة',
    'boundaries.item2': 'تطوير برمجيات أو تنفيذ أنظمة',
    'boundaries.item3': 'خدمات مُدارة أو ملكية تشغيلية',
    'boundaries.item4': 'ضمانات النتائج أو الأداء',

    // Engagement
    'engagement.title': 'هيكل التعاقد',
    'engagement.subtitle': 'مهنية، شفافية، ومسؤولية.',
    'engagement.fixed': 'نطاق محدد',
    'engagement.documented': 'موثق',
    'engagement.contractual': 'تعاقدي',
    'engagement.responsibility': 'مسؤوليتنا هي شرح الخيارات والتداعيات بوضوح. العميل مسؤول عن القرار النهائي والتنفيذ.'

  }
};
