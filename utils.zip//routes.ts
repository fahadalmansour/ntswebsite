export type Language = 'en' | 'ar';

export const routes = {
  home: (lang: Language) => `/${lang}/`,
  privacy: (lang: Language) => `/${lang}/privacy`,
  cookies: (lang: Language) => `/${lang}/cookies`,
  terms: (lang: Language) => `/${lang}/terms`,
  disclaimer: (lang: Language) => `/${lang}/disclaimer`,
  disclosure: (lang: Language) => `/${lang}/disclosure`,
  contact: (lang: Language) => `/${lang}/contact`,
};

export function getLanguageFromPath(pathname: string): Language {
  if (pathname.startsWith('/ar')) return 'ar';
  return 'en';
}

export function getCurrentRoute(pathname: string): string {
  // Remove language prefix and trailing slash
  const withoutLang = pathname.replace(/^\/(en|ar)/, '');
  return withoutLang === '' || withoutLang === '/' ? 'home' : withoutLang.replace(/^\//, '');
}
