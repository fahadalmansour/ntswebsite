<?php
/**
 * Template Name: Disclosure Policy
 * 
 * @package NeoTechnology_Solutions
 */

get_header();
?>

<main id="primary" class="site-main min-h-screen bg-white pt-12 pb-20 px-6">
    <div class="max-w-4xl mx-auto">
        <h1 class="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
            <?php _e('Disclosure Policy', 'neotech'); ?>
        </h1>
        <p class="text-sm text-slate-600 mb-12"><?php _e('Last updated: January 11, 2026', 'neotech'); ?></p>

        <div class="prose prose-slate max-w-none space-y-8">
            <div class="bg-slate-50 rounded-2xl p-8 border border-slate-200 mb-8">
                <p class="text-lg text-slate-900 font-medium text-center">
                    <?php _e('Transparency is fundamental to our advisory practice. This policy explains how we handle potential conflicts of interest.', 'neotech'); ?>
                </p>
            </div>

            <section>
                <h2 class="text-2xl text-slate-900 mb-4 font-medium"><?php _e('Our commitment', 'neotech'); ?></h2>
                <p class="text-slate-700 leading-relaxed">
                    <?php _e('NeoTechnology Solutions LLC is committed to full transparency in all client engagements. We believe clients deserve to know about any relationships or arrangements that could influence our recommendations.', 'neotech'); ?>
                </p>
            </section>

            <section>
                <h2 class="text-2xl text-slate-900 mb-4 font-medium"><?php _e('Vendor introductions', 'neotech'); ?></h2>
                <p class="text-slate-700 leading-relaxed">
                    <?php _e('When clients request vendor introductions or when our advisory work identifies suitable vendors, we may facilitate introductions. In some cases, vendors may offer referral fees or commissions for successful introductions.', 'neotech'); ?>
                </p>
            </section>

            <section>
                <h2 class="text-2xl text-slate-900 mb-4 font-medium"><?php _e('Disclosure process', 'neotech'); ?></h2>
                <p class="text-slate-700 leading-relaxed mb-4">
                    <?php _e('When any referral fee or commission arrangement exists, we commit to:', 'neotech'); ?>
                </p>
                <ul class="space-y-2 text-slate-700">
                    <li class="flex items-start gap-3">
                        <span class="w-1.5 h-1.5 bg-slate-400 rounded-full mt-2 flex-shrink-0"></span>
                        <span><?php _e('Disclosing the arrangement in writing BEFORE making any introduction', 'neotech'); ?></span>
                    </li>
                    <li class="flex items-start gap-3">
                        <span class="w-1.5 h-1.5 bg-slate-400 rounded-full mt-2 flex-shrink-0"></span>
                        <span><?php _e('Documenting the amount or structure of any fees in advance', 'neotech'); ?></span>
                    </li>
                    <li class="flex items-start gap-3">
                        <span class="w-1.5 h-1.5 bg-slate-400 rounded-full mt-2 flex-shrink-0"></span>
                        <span><?php _e('Obtaining client acknowledgment before proceeding', 'neotech'); ?></span>
                    </li>
                </ul>
            </section>

            <section>
                <h2 class="text-2xl text-slate-900 mb-4 font-medium"><?php _e('Client choice', 'neotech'); ?></h2>
                <p class="text-slate-700 leading-relaxed mb-4">
                    <?php _e('Important principles regarding vendor selection:', 'neotech'); ?>
                </p>
                <ul class="space-y-2 text-slate-700">
                    <li class="flex items-start gap-3">
                        <span class="w-1.5 h-1.5 bg-slate-400 rounded-full mt-2 flex-shrink-0"></span>
                        <span><?php _e('Clients are always free to choose any vendor, including those we do not introduce', 'neotech'); ?></span>
                    </li>
                    <li class="flex items-start gap-3">
                        <span class="w-1.5 h-1.5 bg-slate-400 rounded-full mt-2 flex-shrink-0"></span>
                        <span><?php _e('There is no obligation to use vendors we introduce', 'neotech'); ?></span>
                    </li>
                    <li class="flex items-start gap-3">
                        <span class="w-1.5 h-1.5 bg-slate-400 rounded-full mt-2 flex-shrink-0"></span>
                        <span><?php _e('Our advisory recommendations are based on technical fit, not commission potential', 'neotech'); ?></span>
                    </li>
                </ul>
            </section>

            <section>
                <h2 class="text-2xl text-slate-900 mb-4 font-medium"><?php _e('Advisory independence', 'neotech'); ?></h2>
                <p class="text-slate-700 leading-relaxed">
                    <?php _e('Regardless of any referral arrangements, our advisory work remains independent. We evaluate all options based on the client\'s specific requirements, constraints, and objectives. Commission arrangements never influence our technical recommendations.', 'neotech'); ?>
                </p>
            </section>

            <section>
                <h2 class="text-2xl text-slate-900 mb-4 font-medium"><?php _e('No undisclosed relationships', 'neotech'); ?></h2>
                <p class="text-slate-700 leading-relaxed">
                    <?php _e('We do not maintain undisclosed commercial relationships with vendors. If we have any material relationship with a vendor that could be perceived as influencing our advice, we will disclose it.', 'neotech'); ?>
                </p>
            </section>

            <section>
                <h2 class="text-2xl text-slate-900 mb-4 font-medium"><?php _e('Questions', 'neotech'); ?></h2>
                <p class="text-slate-700 leading-relaxed">
                    <?php _e('If you have any questions about our disclosure practices or want to understand more about any specific arrangement, please contact us at', 'neotech'); ?>
                    <a href="mailto:contact@neotechnology.solutions" class="text-slate-900 underline font-medium">
                        contact@neotechnology.solutions
                    </a>
                </p>
            </section>
        </div>
    </div>
</main>

<?php
get_footer();
