<?php
/**
 * The template for displaying the front page (homepage)
 *
 * @package NeoTechnology_Solutions
 */

get_header();
?>

<main id="primary" class="site-main">
    <?php
    // Homepage sections using shortcodes
    echo do_shortcode('[neotech_hero]');
    echo do_shortcode('[neotech_how_we_work]');
    echo do_shortcode('[neotech_decision_areas]');
    echo do_shortcode('[neotech_reference_architecture]');
    echo do_shortcode('[neotech_tools_standards]');
    echo do_shortcode('[neotech_what_you_receive]');
    echo do_shortcode('[neotech_advisory_services]');
    echo do_shortcode('[neotech_boundaries]');
    echo do_shortcode('[neotech_engagement]');
    
    // CTA Section
    ?>
    <section id="contact" class="py-20 px-6 bg-white">
        <div class="max-w-3xl mx-auto text-center">
            <h2 class="text-4xl font-light tracking-tight mb-6 text-slate-900">
                <?php _e('Ready to make a decision?', 'neotech'); ?>
            </h2>
            <p class="text-xl text-slate-600 mb-8">
                <?php _e('If your business needs structured IT guidance, request an initial discussion.', 'neotech'); ?>
            </p>
            <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary inline-flex items-center gap-2">
                <?php _e('Request initial discussion', 'neotech'); ?>
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/>
                </svg>
            </a>
        </div>
    </section>
</main>

<?php
get_footer();
