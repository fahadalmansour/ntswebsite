<?php
/**
 * NeoTechnology Solutions - Theme Functions & Shortcodes
 *
 * @package NeoTechnology_Solutions
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme Setup
 */
function neotech_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', [
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ]);
    add_theme_support('html5', [
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ]);

    // Register navigation menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'neotech'),
        'footer'  => __('Footer Menu', 'neotech'),
    ]);

    // Load text domain for translations
    load_theme_textdomain('neotech', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'neotech_setup');

/**
 * Enqueue Scripts & Styles
 */
function neotech_enqueue_scripts() {
    // Main stylesheet
    wp_enqueue_style(
        'neotech-style',
        get_stylesheet_uri(),
        [],
        wp_get_theme()->get('Version')
    );

    // Navigation script
    wp_enqueue_script(
        'neotech-navigation',
        get_template_directory_uri() . '/js/navigation.js',
        [],
        wp_get_theme()->get('Version'),
        true
    );

    // Cookie consent script
    wp_enqueue_script(
        'neotech-cookie-consent',
        get_template_directory_uri() . '/js/cookie-consent.js',
        [],
        wp_get_theme()->get('Version'),
        true
    );
}
add_action('wp_enqueue_scripts', 'neotech_enqueue_scripts');

/**
 * Body Classes
 */
function neotech_body_classes($classes) {
    if (is_rtl()) {
        $classes[] = 'rtl';
    }
    return $classes;
}
add_filter('body_class', 'neotech_body_classes');

/**
 * Helper: SVG Icons
 */
function neotech_get_icon($name) {
    $icons = [
        'arrow-right' => '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>',
        'arrow-left'  => '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>',
        'check'       => '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>',
        'mail'        => '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>',
    ];
    return isset($icons[$name]) ? $icons[$name] : '';
}

/* ============================================
   SHORTCODES: Homepage Sections
   ============================================ */

/**
 * 1. HERO SECTION
 * [neotech_hero]
 */
function neotech_hero_shortcode() {
    ob_start();
    ?>
    <section class="py-20 px-6 bg-white">
        <div class="max-w-4xl mx-auto text-center mb-16">
            <h1 class="text-5xl font-light tracking-tight mb-6 text-slate-900">
                <?php _e('Independent IT Decision Advisory', 'neotech'); ?>
            </h1>
            <p class="text-xl text-slate-600 mb-12 max-w-2xl mx-auto">
                <?php _e('Structured guidance for operational businesses making critical IT and system decisions.', 'neotech'); ?>
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center mb-16">
                <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary">
                    <?php _e('Request initial discussion', 'neotech'); ?>
                </a>
                <a href="#how-we-work" class="btn btn-secondary">
                    <?php _e('How we work', 'neotech'); ?>
                </a>
            </div>
        </div>

        <div class="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto text-center">
            <div>
                <p class="font-medium mb-2 text-slate-900"><?php _e('No selling', 'neotech'); ?></p>
                <p class="text-sm text-slate-600"><?php _e('We do not sell software or hardware', 'neotech'); ?></p>
            </div>
            <div>
                <p class="font-medium mb-2 text-slate-900"><?php _e('No implementation', 'neotech'); ?></p>
                <p class="text-sm text-slate-600"><?php _e('We do not implement or manage systems', 'neotech'); ?></p>
            </div>
            <div>
                <p class="font-medium mb-2 text-slate-900"><?php _e('Client decides', 'neotech'); ?></p>
                <p class="text-sm text-slate-600"><?php _e('Final decisions are always made by the client', 'neotech'); ?></p>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_hero', 'neotech_hero_shortcode');

/**
 * 2. HOW WE WORK
 * [neotech_how_we_work]
 */
function neotech_how_we_work_shortcode() {
    ob_start();
    $steps = [
        ['01', __('Context & constraints', 'neotech'), __('Understanding your operational environment, requirements, and decision timeline', 'neotech')],
        ['02', __('Options A/B/C', 'neotech'), __('Presenting structured alternatives based on your specific situation', 'neotech')],
        ['03', __('Trade-offs documented', 'neotech'), __('Clear analysis of implications, risks, and operational impact for each option', 'neotech')],
        ['04', __('Decision summary delivered', 'neotech'), __('Structured documentation to support your final decision and next steps', 'neotech')],
    ];
    ?>
    <section id="how-we-work" class="py-16 px-6 bg-white">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('How we work', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('A structured, repeatable approach to clarifying complex IT decisions.', 'neotech'); ?></p>
            </div>
            <div class="grid gap-4">
                <?php foreach ($steps as $step): ?>
                <div class="bg-slate-50 rounded-2xl p-8 border border-slate-200">
                    <div class="flex items-start gap-6">
                        <div class="text-3xl font-light text-slate-400"><?php echo $step[0]; ?></div>
                        <div>
                            <h3 class="text-xl font-medium mb-2 text-slate-900"><?php echo $step[1]; ?></h3>
                            <p class="text-slate-600"><?php echo $step[2]; ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_how_we_work', 'neotech_how_we_work_shortcode');

/**
 * 3. DECISION AREAS
 * [neotech_decision_areas]
 */
function neotech_decision_areas_shortcode() {
    ob_start();
    $areas = [
        [
            'title' => __('Cloud vs On-Prem/Hybrid', 'neotech'),
            'desc'  => __('Evaluate operational fit, risk profile, and long-term flexibility.', 'neotech'),
            'items' => [__('Workload placement', 'neotech'), __('Cost modeling', 'neotech'), __('Vendor lock-in', 'neotech')]
        ],
        [
            'title' => __('Vendor & Scope Selection', 'neotech'),
            'desc'  => __('Compare options and clarify what each party owns and delivers.', 'neotech'),
            'items' => [__('Capability gaps', 'neotech'), __('Support SLAs', 'neotech'), __('Contract terms', 'neotech')]
        ],
        [
            'title' => __('Scale vs Stability', 'neotech'),
            'desc'  => __('Balance growth needs with operational reliability and team capacity.', 'neotech'),
            'items' => [__('Technical debt', 'neotech'), __('Team skills', 'neotech'), __('Monitoring', 'neotech')]
        ]
    ];
    ?>
    <section id="decision-areas" class="py-16 px-6 bg-slate-50">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('Decision Areas', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('We guide businesses through complex IT decisions across three core areas.', 'neotech'); ?></p>
            </div>
            <div class="grid md:grid-cols-3 gap-6">
                <?php foreach ($areas as $area): ?>
                <div class="bg-white rounded-2xl p-8 border border-slate-200">
                    <h3 class="text-xl font-medium mb-4 text-slate-900"><?php echo $area['title']; ?></h3>
                    <p class="text-slate-600 mb-6"><?php echo $area['desc']; ?></p>
                    <ul class="space-y-3">
                        <?php foreach ($area['items'] as $item): ?>
                        <li class="flex items-center gap-3">
                            <div class="w-1.5 h-1.5 bg-slate-400 rounded-full"></div>
                            <span class="text-sm text-slate-600"><?php echo $item; ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_decision_areas', 'neotech_decision_areas_shortcode');

/**
 * 4. REFERENCE ARCHITECTURE
 * [neotech_reference_architecture]
 */
function neotech_ref_arch_shortcode() {
    ob_start();
    $layers = [
        __('Users/Branches', 'neotech'),
        __('Identity & Access', 'neotech'),
        __('Network', 'neotech'),
        __('Apps', 'neotech'),
        __('Data', 'neotech'),
        __('Monitoring/Backups', 'neotech')
    ];
    $is_rtl = is_rtl();
    ?>
    <section id="reference-architecture" class="py-16 px-6 bg-white">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('Reference Architecture', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('We help you think through the full stack.', 'neotech'); ?></p>
            </div>
            <div class="bg-slate-50 rounded-3xl p-8 border border-slate-200">
                <div class="flex flex-col lg:flex-row items-center justify-between gap-6">
                    <?php foreach ($layers as $index => $layer): ?>
                        <div class="flex items-center gap-6 w-full lg:w-auto">
                            <div class="flex-1 lg:flex-initial">
                                <div class="bg-white rounded-xl px-6 py-5 border border-slate-200 text-center min-w-[140px]">
                                    <p class="text-slate-900 font-medium text-sm whitespace-nowrap"><?php echo $layer; ?></p>
                                </div>
                            </div>
                            <?php if ($index < count($layers) - 1): ?>
                                <div class="hidden lg:block text-slate-400">
                                    <?php echo $is_rtl ? neotech_get_icon('arrow-left') : neotech_get_icon('arrow-right'); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="mt-8 pt-8 border-t border-slate-200 text-center">
                    <p class="text-sm text-slate-600"><?php _e('High-level view only. We document responsibilities for each layer.', 'neotech'); ?></p>
                </div>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_reference_architecture', 'neotech_ref_arch_shortcode');

/**
 * 5. TOOLS & STANDARDS
 * [neotech_tools_standards]
 */
function neotech_tools_shortcode() {
    ob_start();
    $cats = [
        [__('SSO/MFA', 'neotech'), __('Identity federation, multi-factor authentication', 'neotech')],
        [__('Monitoring', 'neotech'), __('Infrastructure metrics, application logs', 'neotech')],
        [__('Backups (RPO/RTO)', 'neotech'), __('Recovery point objectives, testing cadence', 'neotech')],
        [__('Security Baseline', 'neotech'), __('Patching, hardening, access controls', 'neotech')],
        [__('Cloud Cost Controls', 'neotech'), __('Budget alerts, resource tagging', 'neotech')],
        [__('Network', 'neotech'), __('VPN, direct connect, segmentation', 'neotech')]
    ];
    ?>
    <section id="tools-standards" class="py-16 px-6 bg-slate-50">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('Tools & Standards', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('Clarifying requirements without pushing vendors.', 'neotech'); ?></p>
            </div>
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($cats as $cat): ?>
                <div class="bg-white rounded-xl p-6 border border-slate-200">
                    <h3 class="text-slate-900 font-medium mb-2"><?php echo $cat[0]; ?></h3>
                    <p class="text-sm text-slate-600"><?php echo $cat[1]; ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_tools_standards', 'neotech_tools_shortcode');

/**
 * 6. WHAT YOU RECEIVE
 * [neotech_what_you_receive]
 */
function neotech_deliverables_shortcode() {
    ob_start();
    $items = [
        [__('Decision summary PDF', 'neotech'), __('Comprehensive documentation of context and options', 'neotech')],
        [__('A/B/C comparison', 'neotech'), __('Structured analysis of alternatives', 'neotech')],
        [__('Scope map', 'neotech'), __('Clear definition of responsibilities', 'neotech')],
        [__('Vendor questions', 'neotech'), __('Structured questions to clarify proposals', 'neotech')],
        [__('Architecture notes', 'neotech'), __('Reference diagram and integration points', 'neotech')]
    ];
    ?>
    <section id="what-you-receive" class="py-16 px-6 bg-white">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('What you receive', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('Structured deliverables designed to support your decision-making.', 'neotech'); ?></p>
            </div>
            <div class="space-y-3">
                <?php foreach ($items as $idx => $item): ?>
                <div class="bg-slate-50 rounded-xl p-6 border border-slate-200">
                    <div class="flex items-start gap-4">
                        <div class="flex-shrink-0 w-8 h-8 bg-slate-900 text-white rounded-lg flex items-center justify-center text-sm font-medium">
                            <?php echo $idx + 1; ?>
                        </div>
                        <div>
                            <h3 class="text-slate-900 font-medium mb-1"><?php echo $item[0]; ?></h3>
                            <p class="text-sm text-slate-600"><?php echo $item[1]; ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_what_you_receive', 'neotech_deliverables_shortcode');

/**
 * 7. ADVISORY SERVICES
 * [neotech_advisory_services]
 */
function neotech_advisory_services_shortcode() {
    ob_start();
    ?>
    <section id="advisory-services" class="py-16 px-6 bg-slate-50">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('Advisory Services', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('Two engagement models to match your situation.', 'neotech'); ?></p>
            </div>
            
            <div class="grid lg:grid-cols-2 gap-6">
                <!-- Direct -->
                <div class="bg-white rounded-2xl p-10 border border-slate-200">
                    <h3 class="text-2xl font-medium mb-4 text-slate-900"><?php _e('Direct Decision Advisory', 'neotech'); ?></h3>
                    <p class="text-slate-600 mb-8"><?php _e('We work directly with your team to provide structured, neutral guidance for IT decisions.', 'neotech'); ?></p>
                    <div class="pt-6 border-t border-slate-200">
                        <p class="text-slate-900 font-medium mb-1"><?php _e('The business makes the final decision.', 'neotech'); ?></p>
                    </div>
                </div>
                <!-- Vendor -->
                <div class="bg-white rounded-2xl p-10 border border-slate-200">
                    <h3 class="text-2xl font-medium mb-4 text-slate-900"><?php _e('Vendor-Assisted Decision Advisory', 'neotech'); ?></h3>
                    <p class="text-slate-600 mb-8"><?php _e('When vendors or integrators are involved, we act as a neutral advisor.', 'neotech'); ?></p>
                    <div class="pt-6 border-t border-slate-200">
                         <p class="text-sm text-slate-600"><?php _e('Any commissions are fully disclosed.', 'neotech'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_advisory_services', 'neotech_advisory_services_shortcode');

/**
 * 8. BOUNDARIES
 * [neotech_boundaries]
 */
function neotech_boundaries_shortcode() {
    ob_start();
    $items = [
        __('Ongoing IT support or system administration', 'neotech'),
        __('Software development or system implementation', 'neotech'),
        __('Managed services or operational ownership', 'neotech'),
        __('Outcome or performance guarantees', 'neotech')
    ];
    ?>
    <section id="boundaries" class="py-16 px-6 bg-white">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('What we do not do', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('Our role is advisory and decision-focused only.', 'neotech'); ?></p>
            </div>
            <div class="bg-slate-50 rounded-2xl p-8 border border-slate-200">
                <ul class="grid sm:grid-cols-2 gap-4">
                    <?php foreach ($items as $item): ?>
                    <li class="flex items-center gap-3 text-slate-700">
                        <div class="w-1.5 h-1.5 bg-slate-400 rounded-full flex-shrink-0"></div>
                        <span><?php echo $item; ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_boundaries', 'neotech_boundaries_shortcode');

/**
 * 9. ENGAGEMENT
 * [neotech_engagement]
 */
function neotech_engagement_shortcode() {
    ob_start();
    ?>
    <section id="engagement" class="py-16 px-6 bg-slate-50">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('Engagement structure', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('Professional, transparent, and accountable.', 'neotech'); ?></p>
            </div>
            <div class="grid sm:grid-cols-3 gap-6 mb-10">
                <div class="bg-white rounded-xl p-8 border border-slate-200 text-center">
                    <p class="text-lg text-slate-900 font-medium"><?php _e('Fixed-scope', 'neotech'); ?></p>
                </div>
                <div class="bg-white rounded-xl p-8 border border-slate-200 text-center">
                    <p class="text-lg text-slate-900 font-medium"><?php _e('Documented', 'neotech'); ?></p>
                </div>
                <div class="bg-white rounded-xl p-8 border border-slate-200 text-center">
                    <p class="text-lg text-slate-900 font-medium"><?php _e('Contractual', 'neotech'); ?></p>
                </div>
            </div>
            <div class="max-w-3xl mx-auto bg-white rounded-2xl p-10 border border-slate-200 text-center">
                <p class="text-slate-700 text-lg">
                    <?php _e('Our responsibility is to explain options and implications clearly. The client is responsible for the final decision and execution.', 'neotech'); ?>
                </p>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_engagement', 'neotech_engagement_shortcode');

/**
 * 10. CONTACT FORM SHORTCODE
 * [neotech_contact_form]
 */
function neotech_contact_form_shortcode() {
    ob_start();
    ?>
    <div class="bg-slate-50 rounded-3xl p-8 border border-slate-200">
        <?php
        // Use Contact Form 7 if available
        if (shortcode_exists('contact-form-7')) {
            // Look for a contact form with the slug 'advisory-inquiry'
            $form = get_page_by_path('advisory-inquiry', OBJECT, 'wpcf7_contact_form');
            if ($form) {
                echo do_shortcode('[contact-form-7 id="' . $form->ID . '"]');
            } else {
                echo '<p class="text-slate-600">' . __('Please configure Contact Form 7 with a form titled "advisory-inquiry"', 'neotech') . '</p>';
            }
        } else {
            // Fallback mailto form
            ?>
            <form action="mailto:contact@neotechnology.solutions" method="post" enctype="text/plain" class="space-y-6">
                <div>
                    <label for="company" class="block text-sm font-medium text-slate-900 mb-2">
                        <?php _e('Company name *', 'neotech'); ?>
                    </label>
                    <input type="text" id="company" name="company" required
                           class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white"
                           placeholder="<?php esc_attr_e('Your organization', 'neotech'); ?>">
                </div>
                
                <div>
                    <label for="name" class="block text-sm font-medium text-slate-900 mb-2">
                        <?php _e('Your name *', 'neotech'); ?>
                    </label>
                    <input type="text" id="name" name="name" required
                           class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white"
                           placeholder="<?php esc_attr_e('Full name', 'neotech'); ?>">
                </div>
                
                <div>
                    <label for="email" class="block text-sm font-medium text-slate-900 mb-2">
                        <?php _e('Business email *', 'neotech'); ?>
                    </label>
                    <input type="email" id="email" name="email" required
                           class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white"
                           placeholder="your.name@company.com">
                </div>
                
                <div>
                    <label for="phone" class="block text-sm font-medium text-slate-900 mb-2">
                        <?php _e('Phone (optional)', 'neotech'); ?>
                    </label>
                    <input type="tel" id="phone" name="phone"
                           class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white"
                           placeholder="+966 XX XXX XXXX">
                </div>
                
                <div>
                    <label for="decision_type" class="block text-sm font-medium text-slate-900 mb-2">
                        <?php _e('Decision type *', 'neotech'); ?>
                    </label>
                    <select id="decision_type" name="decision_type" required
                            class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white">
                        <option value=""><?php _e('Select one', 'neotech'); ?></option>
                        <option value="cloud"><?php _e('Cloud vs On-Prem/Hybrid', 'neotech'); ?></option>
                        <option value="vendor"><?php _e('Vendor/Scope selection', 'neotech'); ?></option>
                        <option value="scale"><?php _e('Scale vs Stability', 'neotech'); ?></option>
                        <option value="other"><?php _e('Other', 'neotech'); ?></option>
                    </select>
                </div>
                
                <div>
                    <label for="message" class="block text-sm font-medium text-slate-900 mb-2">
                        <?php _e('What do you need help with? *', 'neotech'); ?>
                    </label>
                    <textarea id="message" name="message" rows="5" required
                              class="w-full px-4 py-3 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-slate-900 bg-white resize-none"
                              placeholder="<?php esc_attr_e('Brief description of your situation and what decision you\'re facing...', 'neotech'); ?>"></textarea>
                </div>
                
                <div class="bg-white rounded-xl p-4 border border-slate-300">
                    <label class="flex items-start gap-3 cursor-pointer">
                        <input type="checkbox" name="consent" required
                               class="mt-1 w-4 h-4 text-slate-900 border-slate-300 rounded focus:ring-slate-900">
                        <span class="text-sm text-slate-700 leading-relaxed">
                            <?php _e('I understand this is advisory only (not implementation). NeoTechnology Solutions LLC does not implement systems or provide managed services.', 'neotech'); ?>
                        </span>
                    </label>
                </div>
                
                <button type="submit" class="w-full btn btn-primary">
                    <?php _e('Submit request', 'neotech'); ?>
                </button>
                
                <p class="text-center text-sm text-slate-600">
                    <?php _e('We reply within 1 business day', 'neotech'); ?>
                </p>
            </form>
            <?php
        }
        ?>
    </div>
    
    <div class="mt-8 text-center">
        <p class="text-sm text-slate-600 mb-3">
            <?php _e('Prefer email directly?', 'neotech'); ?>
        </p>
        <a href="mailto:contact@neotechnology.solutions" class="inline-flex items-center gap-2 text-slate-900 hover:text-slate-700 transition-colors">
            <?php echo neotech_get_icon('mail'); ?>
            <span class="font-medium">contact@neotechnology.solutions</span>
        </a>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_contact_form', 'neotech_contact_form_shortcode');

/* ============================================
   SOCIAL MEDIA SETTINGS & SHORTCODE
   ============================================ */

/**
 * Register Social Media Customizer Settings
 */
function neotech_customize_social($wp_customize) {
    // Section: Social Media
    $wp_customize->add_section('neotech_social_section', [
        'title'       => __('Social Media Links', 'neotech'),
        'description' => __('Add your social media profile URLs here.', 'neotech'),
        'priority'    => 121,
    ]);

    // LinkedIn
    $wp_customize->add_setting('neotech_linkedin', ['sanitize_callback' => 'esc_url_raw']);
    $wp_customize->add_control('neotech_linkedin', [
        'type'     => 'url',
        'label'    => __('LinkedIn URL', 'neotech'),
        'section'  => 'neotech_social_section',
    ]);

    // Twitter / X
    $wp_customize->add_setting('neotech_twitter', ['sanitize_callback' => 'esc_url_raw']);
    $wp_customize->add_control('neotech_twitter', [
        'type'     => 'url',
        'label'    => __('Twitter / X URL', 'neotech'),
        'section'  => 'neotech_social_section',
    ]);

    // YouTube
    $wp_customize->add_setting('neotech_youtube', ['sanitize_callback' => 'esc_url_raw']);
    $wp_customize->add_control('neotech_youtube', [
        'type'     => 'url',
        'label'    => __('YouTube URL', 'neotech'),
        'section'  => 'neotech_social_section',
    ]);
}
add_action('customize_register', 'neotech_customize_social');

/**
 * Shortcode: Display Social Icons
 * [neotech_social_links]
 */
function neotech_social_links_shortcode() {
    $linkedin = get_theme_mod('neotech_linkedin');
    $twitter  = get_theme_mod('neotech_twitter');
    $youtube  = get_theme_mod('neotech_youtube');

    if (!$linkedin && !$twitter && !$youtube) return '';

    ob_start();
    ?>
    <div class="flex items-center gap-4 social-links">
        <?php if ($linkedin): ?>
            <a href="<?php echo esc_url($linkedin); ?>" target="_blank" rel="noopener noreferrer" class="text-slate-400 hover:text-[#0077b5] transition-colors" aria-label="LinkedIn">
                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"/></svg>
            </a>
        <?php endif; ?>
        
        <?php if ($twitter): ?>
            <a href="<?php echo esc_url($twitter); ?>" target="_blank" rel="noopener noreferrer" class="text-slate-400 hover:text-black transition-colors" aria-label="Twitter / X">
                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
            </a>
        <?php endif; ?>

        <?php if ($youtube): ?>
            <a href="<?php echo esc_url($youtube); ?>" target="_blank" rel="noopener noreferrer" class="text-slate-400 hover:text-[#FF0000] transition-colors" aria-label="YouTube">
                <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
            </a>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_social_links', 'neotech_social_links_shortcode');

/* ============================================
   CUSTOMIZER & TRACKING SCRIPTS
   ============================================ */

/**
 * Register Customizer Settings for Tracking
 */
function neotech_customize_register($wp_customize) {
    // Section: Tracking & Scripts
    $wp_customize->add_section('neotech_tracking_section', [
        'title'       => __('Tracking & Scripts', 'neotech'),
        'description' => __('Add tracking IDs. These will normally be loaded via the Cookie Consent banner for compliance.', 'neotech'),
        'priority'    => 120,
    ]);

    // 1. Google Analytics ID
    $wp_customize->add_setting('neotech_ga_id', ['sanitize_callback' => 'sanitize_text_field']);
    $wp_customize->add_control('neotech_ga_id', [
        'type'     => 'text',
        'label'    => __('Google Analytics ID (G-XXXXXXXXXX)', 'neotech'),
        'section'  => 'neotech_tracking_section',
    ]);

    // 2. Google Tag Manager ID
    $wp_customize->add_setting('neotech_gtm_id', ['sanitize_callback' => 'sanitize_text_field']);
    $wp_customize->add_control('neotech_gtm_id', [
        'type'     => 'text',
        'label'    => __('Google Tag Manager ID (GTM-XXXXXXX)', 'neotech'),
        'section'  => 'neotech_tracking_section',
    ]);

    // 3. Meta Pixel ID (New)
    $wp_customize->add_setting('neotech_pixel_id', ['sanitize_callback' => 'sanitize_text_field']);
    $wp_customize->add_control('neotech_pixel_id', [
        'type'     => 'text',
        'label'    => __('Meta Pixel ID (1234567890)', 'neotech'),
        'section'  => 'neotech_tracking_section',
    ]);

    // 4. Custom Head Scripts (Always loaded)
    $wp_customize->add_setting('neotech_header_scripts', ['sanitize_callback' => 'neotech_sanitize_scripts']);
    $wp_customize->add_control('neotech_header_scripts', [
        'type'     => 'textarea',
        'label'    => __('Custom Header Scripts (Always Loaded)', 'neotech'),
        'description' => __('Scripts essential for the site (e.g., verification tags). NOT for tracking.', 'neotech'),
        'section'  => 'neotech_tracking_section',
    ]);
}
add_action('customize_register', 'neotech_customize_register');

/**
 * Sanitize Scripts
 */
function neotech_sanitize_scripts($input) {
    return $input; 
}

/**
 * Pass IDs to JavaScript (for Cookie Consent)
 */
function neotech_localize_tracking_scripts() {
    $data = [
        'ga_id'    => get_theme_mod('neotech_ga_id'),
        'gtm_id'   => get_theme_mod('neotech_gtm_id'),
        'pixel_id' => get_theme_mod('neotech_pixel_id'),
    ];
    wp_localize_script('neotech-cookie-consent', 'neotechParams', $data);
}
add_action('wp_enqueue_scripts', 'neotech_localize_tracking_scripts', 20);

/**
 * Output Essential Scripts only
 */
function neotech_essential_scripts_head() {
    $header_scripts = get_theme_mod('neotech_header_scripts');
    if ($header_scripts) {
        echo $header_scripts . "\n";
    }
}
add_action('wp_head', 'neotech_essential_scripts_head', 1);
