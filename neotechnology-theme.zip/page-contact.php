<?php
/**
 * Template Name: Contact Page
 * 
 * @package NeoTechnology_Solutions
 */

get_header();
?>

<main id="primary" class="site-main min-h-screen bg-white pt-12 pb-20 px-6">
    <div class="max-w-3xl mx-auto">
        <div class="text-center mb-12">
            <h1 class="text-4xl sm:text-5xl text-slate-900 mb-4 tracking-tight font-light">
                <?php _e('Request an initial discussion', 'neotech'); ?>
            </h1>
            <p class="text-xl text-slate-700 mb-4 leading-relaxed">
                <?php _e('If your business needs to make an IT decision and wants structured, honest guidance, request an initial discussion.', 'neotech'); ?>
            </p>
            <p class="text-sm text-slate-600">
                <?php _e('We reply within 1 business day.', 'neotech'); ?>
            </p>
        </div>

        <?php echo do_shortcode('[neotech_contact_form]'); ?>
    </div>
</main>

<?php
get_footer();
