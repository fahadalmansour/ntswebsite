<?php
/**
 * The footer template
 *
 * @package NeoTechnology_Solutions
 */

$is_rtl = is_rtl();
?>
    </div><!-- #content -->

    <footer id="colophon" class="site-footer bg-slate-50 border-t border-slate-200">
        <div class="max-w-7xl mx-auto px-6 py-16">
            <!-- Footer Grid -->
            <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
                <!-- Company Info -->
                <div class="lg:col-span-2">
                    <h3 class="text-lg font-semibold text-slate-900 mb-4">NeoTechnology Solutions</h3>
                    <p class="text-slate-600 mb-4 max-w-md">
                        <?php _e('Independent IT decision advisory for operational businesses. We provide structured, neutral guidance — no selling, no implementation.', 'neotech'); ?>
                    </p>
                    <p class="text-sm text-slate-500">
                        <?php _e('Advisory only — No implementation', 'neotech'); ?>
                    </p>
                </div>

                <!-- Legal Links -->
                <div>
                    <h4 class="font-medium text-slate-900 mb-4"><?php _e('Legal', 'neotech'); ?></h4>
                    <nav class="space-y-2">
                        <a href="<?php echo esc_url(home_url('/privacy/')); ?>" class="block text-slate-600 hover:text-slate-900 transition-colors text-sm">
                            <?php _e('Privacy Policy', 'neotech'); ?>
                        </a>
                        <a href="<?php echo esc_url(home_url('/cookies/')); ?>" class="block text-slate-600 hover:text-slate-900 transition-colors text-sm">
                            <?php _e('Cookie Policy', 'neotech'); ?>
                        </a>
                        <a href="<?php echo esc_url(home_url('/terms/')); ?>" class="block text-slate-600 hover:text-slate-900 transition-colors text-sm">
                            <?php _e('Terms of Use', 'neotech'); ?>
                        </a>
                        <a href="<?php echo esc_url(home_url('/disclaimer/')); ?>" class="block text-slate-600 hover:text-slate-900 transition-colors text-sm">
                            <?php _e('Advisory Disclaimer', 'neotech'); ?>
                        </a>
                        <a href="<?php echo esc_url(home_url('/disclosure/')); ?>" class="block text-slate-600 hover:text-slate-900 transition-colors text-sm">
                            <?php _e('Disclosure Policy', 'neotech'); ?>
                        </a>
                    </nav>
                </div>

                <!-- Contact -->
                <div>
                    <h4 class="font-medium text-slate-900 mb-4"><?php _e('Contact', 'neotech'); ?></h4>
                    <nav class="space-y-2">
                        <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="block text-slate-600 hover:text-slate-900 transition-colors text-sm">
                            <?php _e('Request a Discussion', 'neotech'); ?>
                        </a>
                        <a href="mailto:contact@neotechnology.solutions" class="block text-slate-600 hover:text-slate-900 transition-colors text-sm">
                            contact@neotechnology.solutions
                        </a>
                    </nav>
                    <div class="mt-6">
                        <div class="mb-4">
                            <?php echo do_shortcode('[neotech_social_links]'); ?>
                        </div>
                        <p class="text-sm text-slate-500">
                            <?php _e('We reply within 1 business day', 'neotech'); ?>
                        </p>
                    </div>
                </div>
            </div>

            <!-- Bottom Bar -->
            <div class="pt-8 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-4">
                <p class="text-sm text-slate-500">
                    © <?php echo date('Y'); ?> NeoTechnology Solutions LLC. <?php _e('All rights reserved.', 'neotech'); ?>
                </p>
                <a href="#page" class="text-sm text-slate-600 hover:text-slate-900 transition-colors inline-flex items-center gap-1">
                    <?php _e('Back to top', 'neotech'); ?>
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 10l7-7m0 0l7 7m-7-7v18"/>
                    </svg>
                </a>
            </div>
        </div>
    </footer>
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
