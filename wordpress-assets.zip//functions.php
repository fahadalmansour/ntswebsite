<?php
/**
 * NeoTechnology Solutions - Theme Functions & Shortcodes
 */

function neotechnology_enqueue_scripts() {
    // 1. Enqueue Main Styles
    wp_enqueue_style(
        'neotech-main-style',
        get_template_directory_uri() . '/style.css',
        array(),
        '1.0.0'
    );

    // 2. Enqueue Cookie Consent Script
    wp_enqueue_script(
        'neotech-cookie-consent',
        get_template_directory_uri() . '/js/cookie-consent.js',
        array(),
        '1.0.0',
        true // Load in footer
    );
}
add_action('wp_enqueue_scripts', 'neotechnology_enqueue_scripts');

/**
 * Helper: SVG Icons
 */
function neotech_get_icon($name) {
    switch ($name) {
        case 'arrow-right':
            return '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>';
        case 'arrow-left':
            return '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 19-7-7 7-7"/><path d="M19 12H5"/></svg>';
        case 'check':
            return '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>';
        default:
            return '';
    }
}

/**
 * 1. HERO SECTION
 * [neotech_hero]
 */
function neotech_hero_shortcode() {
    ob_start();
    ?>
    <section class="py-20 px-6 bg-white">
        <div class="max-w-4xl mx-auto text-center mb-16">
            <h1 class="text-5xl font-light tracking-tight mb-6 text-slate-900">
                <?php _e('Independent IT Decision Advisory', 'neotech'); ?>
            </h1>
            <p class="text-xl text-slate-600 mb-12 max-w-2xl mx-auto">
                <?php _e('Structured guidance for operational businesses making critical IT and system decisions.', 'neotech'); ?>
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center mb-16">
                <a href="#contact" class="btn btn-primary">
                    <?php _e('Request initial discussion', 'neotech'); ?>
                </a>
                <a href="#how-we-work" class="btn btn-secondary">
                    <?php _e('How we work', 'neotech'); ?>
                </a>
            </div>
        </div>

        <div class="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto text-center">
            <div>
                <p class="font-medium mb-2 text-slate-900"><?php _e('No selling', 'neotech'); ?></p>
                <p class="text-sm text-slate-600"><?php _e('We do not sell software or hardware', 'neotech'); ?></p>
            </div>
            <div>
                <p class="font-medium mb-2 text-slate-900"><?php _e('No implementation', 'neotech'); ?></p>
                <p class="text-sm text-slate-600"><?php _e('We do not implement or manage systems', 'neotech'); ?></p>
            </div>
            <div>
                <p class="font-medium mb-2 text-slate-900"><?php _e('Client decides', 'neotech'); ?></p>
                <p class="text-sm text-slate-600"><?php _e('Final decisions are always made by the client', 'neotech'); ?></p>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_hero', 'neotech_hero_shortcode');

/**
 * 2. HOW WE WORK
 * [neotech_how_we_work]
 */
function neotech_how_we_work_shortcode() {
    ob_start();
    $steps = [
        ['01', __('Context & constraints', 'neotech'), __('Understanding your operational environment, requirements, and decision timeline', 'neotech')],
        ['02', __('Options A/B/C', 'neotech'), __('Presenting structured alternatives based on your specific situation', 'neotech')],
        ['03', __('Trade-offs documented', 'neotech'), __('Clear analysis of implications, risks, and operational impact for each option', 'neotech')],
        ['04', __('Decision summary delivered', 'neotech'), __('Structured documentation to support your final decision and next steps', 'neotech')],
    ];
    ?>
    <section id="how-we-work" class="py-16 px-6 bg-white">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('How we work', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('A structured, repeatable approach to clarifying complex IT decisions.', 'neotech'); ?></p>
            </div>
            <div class="grid gap-4">
                <?php foreach ($steps as $step): ?>
                <div class="bg-slate-50 rounded-2xl p-8 border border-slate-200">
                    <div class="flex items-start gap-6">
                        <div class="text-3xl font-light text-slate-400"><?php echo $step[0]; ?></div>
                        <div>
                            <h3 class="text-xl font-medium mb-2 text-slate-900"><?php echo $step[1]; ?></h3>
                            <p class="text-slate-600"><?php echo $step[2]; ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_how_we_work', 'neotech_how_we_work_shortcode');

/**
 * 3. DECISION AREAS
 * [neotech_decision_areas]
 */
function neotech_decision_areas_shortcode() {
    ob_start();
    $areas = [
        [
            'title' => __('Cloud vs On-Prem/Hybrid', 'neotech'),
            'desc'  => __('Evaluate operational fit, risk profile, and long-term flexibility.', 'neotech'),
            'items' => [__('Workload placement', 'neotech'), __('Cost modeling', 'neotech'), __('Vendor lock-in', 'neotech')]
        ],
        [
            'title' => __('Vendor & Scope Selection', 'neotech'),
            'desc'  => __('Compare options and clarify what each party owns and delivers.', 'neotech'),
            'items' => [__('Capability gaps', 'neotech'), __('Support SLAs', 'neotech'), __('Contract terms', 'neotech')]
        ],
        [
            'title' => __('Scale vs Stability', 'neotech'),
            'desc'  => __('Balance growth needs with operational reliability and team capacity.', 'neotech'),
            'items' => [__('Technical debt', 'neotech'), __('Team skills', 'neotech'), __('Monitoring', 'neotech')]
        ]
    ];
    ?>
    <section id="decision-areas" class="py-16 px-6 bg-slate-50">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('Decision Areas', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('We guide businesses through complex IT decisions across three core areas.', 'neotech'); ?></p>
            </div>
            <div class="grid md:grid-cols-3 gap-6">
                <?php foreach ($areas as $area): ?>
                <div class="bg-white rounded-2xl p-8 border border-slate-200">
                    <h3 class="text-xl font-medium mb-4 text-slate-900"><?php echo $area['title']; ?></h3>
                    <p class="text-slate-600 mb-6"><?php echo $area['desc']; ?></p>
                    <ul class="space-y-3">
                        <?php foreach ($area['items'] as $item): ?>
                        <li class="flex items-center gap-3">
                            <div class="w-1.5 h-1.5 bg-slate-400 rounded-full"></div>
                            <span class="text-sm text-slate-600"><?php echo $item; ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_decision_areas', 'neotech_decision_areas_shortcode');

/**
 * 4. REFERENCE ARCHITECTURE
 * [neotech_reference_architecture]
 */
function neotech_ref_arch_shortcode() {
    ob_start();
    $layers = [
        __('Users/Branches', 'neotech'),
        __('Identity & Access', 'neotech'),
        __('Network', 'neotech'),
        __('Apps', 'neotech'),
        __('Data', 'neotech'),
        __('Monitoring/Backups', 'neotech')
    ];
    $is_rtl = is_rtl();
    ?>
    <section id="reference-architecture" class="py-16 px-6 bg-white">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('Reference Architecture', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('We help you think through the full stack.', 'neotech'); ?></p>
            </div>
            <div class="bg-slate-50 rounded-3xl p-8 border border-slate-200">
                <div class="flex flex-col lg:flex-row items-center justify-between gap-6">
                    <?php foreach ($layers as $index => $layer): ?>
                        <div class="flex items-center gap-6 w-full lg:w-auto">
                            <div class="flex-1 lg:flex-initial">
                                <div class="bg-white rounded-xl px-6 py-5 border border-slate-200 text-center min-w-[140px]">
                                    <p class="text-slate-900 font-medium text-sm whitespace-nowrap"><?php echo $layer; ?></p>
                                </div>
                            </div>
                            <?php if ($index < count($layers) - 1): ?>
                                <div class="hidden lg:block text-slate-400">
                                    <?php echo $is_rtl ? neotech_get_icon('arrow-left') : neotech_get_icon('arrow-right'); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="mt-8 pt-8 border-t border-slate-200 text-center">
                    <p class="text-sm text-slate-600"><?php _e('High-level view only. We document responsibilities for each layer.', 'neotech'); ?></p>
                </div>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_reference_architecture', 'neotech_ref_arch_shortcode');

/**
 * 5. TOOLS & STANDARDS
 * [neotech_tools_standards]
 */
function neotech_tools_shortcode() {
    ob_start();
    $cats = [
        [__('SSO/MFA', 'neotech'), __('Identity federation, multi-factor authentication', 'neotech')],
        [__('Monitoring', 'neotech'), __('Infrastructure metrics, application logs', 'neotech')],
        [__('Backups (RPO/RTO)', 'neotech'), __('Recovery point objectives, testing cadence', 'neotech')],
        [__('Security Baseline', 'neotech'), __('Patching, hardening, access controls', 'neotech')],
        [__('Cloud Cost Controls', 'neotech'), __('Budget alerts, resource tagging', 'neotech')],
        [__('Network', 'neotech'), __('VPN, direct connect, segmentation', 'neotech')]
    ];
    ?>
    <section id="tools-standards" class="py-16 px-6 bg-slate-50">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('Tools & Standards', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('Clarifying requirements without pushing vendors.', 'neotech'); ?></p>
            </div>
            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php foreach ($cats as $cat): ?>
                <div class="bg-white rounded-xl p-6 border border-slate-200">
                    <h3 class="text-slate-900 font-medium mb-2"><?php echo $cat[0]; ?></h3>
                    <p class="text-sm text-slate-600"><?php echo $cat[1]; ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_tools_standards', 'neotech_tools_shortcode');

/**
 * 6. WHAT YOU RECEIVE
 * [neotech_what_you_receive]
 */
function neotech_deliverables_shortcode() {
    ob_start();
    $items = [
        [__('Decision summary PDF', 'neotech'), __('Comprehensive documentation of context and options', 'neotech')],
        [__('A/B/C comparison', 'neotech'), __('Structured analysis of alternatives', 'neotech')],
        [__('Scope map', 'neotech'), __('Clear definition of responsibilities', 'neotech')],
        [__('Vendor questions', 'neotech'), __('Structured questions to clarify proposals', 'neotech')],
        [__('Architecture notes', 'neotech'), __('Reference diagram and integration points', 'neotech')]
    ];
    ?>
    <section id="what-you-receive" class="py-16 px-6 bg-white">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('What you receive', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('Structured deliverables designed to support your decision-making.', 'neotech'); ?></p>
            </div>
            <div class="space-y-3">
                <?php foreach ($items as $idx => $item): ?>
                <div class="bg-slate-50 rounded-xl p-6 border border-slate-200">
                    <div class="flex items-start gap-4">
                        <div class="flex-shrink-0 w-8 h-8 bg-slate-900 text-white rounded-lg flex items-center justify-center text-sm font-medium">
                            <?php echo $idx + 1; ?>
                        </div>
                        <div>
                            <h3 class="text-slate-900 font-medium mb-1"><?php echo $item[0]; ?></h3>
                            <p class="text-sm text-slate-600"><?php echo $item[1]; ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_what_you_receive', 'neotech_deliverables_shortcode');

/**
 * 7. ADVISORY SERVICES
 * [neotech_advisory_services]
 */
function neotech_advisory_services_shortcode() {
    ob_start();
    ?>
    <section id="advisory-services" class="py-16 px-6 bg-slate-50">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('Advisory Services', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('Two engagement models to match your situation.', 'neotech'); ?></p>
            </div>
            
            <div class="grid lg:grid-cols-2 gap-6">
                <!-- Direct -->
                <div class="bg-white rounded-2xl p-10 border border-slate-200">
                    <h3 class="text-2xl font-medium mb-4 text-slate-900"><?php _e('Direct Decision Advisory', 'neotech'); ?></h3>
                    <p class="text-slate-600 mb-8"><?php _e('We work directly with your team to provide structured, neutral guidance for IT decisions.', 'neotech'); ?></p>
                    <div class="pt-6 border-t border-slate-200">
                        <p class="text-slate-900 font-medium mb-1"><?php _e('The business makes the final decision.', 'neotech'); ?></p>
                    </div>
                </div>
                <!-- Vendor -->
                <div class="bg-white rounded-2xl p-10 border border-slate-200">
                    <h3 class="text-2xl font-medium mb-4 text-slate-900"><?php _e('Vendor-Assisted Decision Advisory', 'neotech'); ?></h3>
                    <p class="text-slate-600 mb-8"><?php _e('When vendors or integrators are involved, we act as a neutral advisor.', 'neotech'); ?></p>
                    <div class="pt-6 border-t border-slate-200">
                         <p class="text-sm text-slate-600"><?php _e('Any commissions are fully disclosed.', 'neotech'); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_advisory_services', 'neotech_advisory_services_shortcode');

/**
 * 8. BOUNDARIES
 * [neotech_boundaries]
 */
function neotech_boundaries_shortcode() {
    ob_start();
    $items = [
        __('Ongoing IT support or system administration', 'neotech'),
        __('Software development or system implementation', 'neotech'),
        __('Managed services or operational ownership', 'neotech'),
        __('Outcome or performance guarantees', 'neotech')
    ];
    ?>
    <section id="boundaries" class="py-16 px-6 bg-white">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('What we do not do', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('Our role is advisory and decision-focused only.', 'neotech'); ?></p>
            </div>
            <div class="bg-slate-50 rounded-2xl p-8 border border-slate-200">
                <ul class="grid sm:grid-cols-2 gap-4">
                    <?php foreach ($items as $item): ?>
                    <li class="flex items-center gap-3 text-slate-700">
                        <div class="w-1.5 h-1.5 bg-slate-400 rounded-full flex-shrink-0"></div>
                        <span><?php echo $item; ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_boundaries', 'neotech_boundaries_shortcode');

/**
 * 9. ENGAGEMENT
 * [neotech_engagement]
 */
function neotech_engagement_shortcode() {
    ob_start();
    ?>
    <section id="engagement" class="py-16 px-6 bg-slate-50">
        <div class="max-w-5xl mx-auto">
            <div class="max-w-3xl mb-12">
                <h2 class="text-4xl font-light tracking-tight mb-4 text-slate-900"><?php _e('Engagement structure', 'neotech'); ?></h2>
                <p class="text-xl text-slate-600"><?php _e('Professional, transparent, and accountable.', 'neotech'); ?></p>
            </div>
            <div class="grid sm:grid-cols-3 gap-6 mb-10">
                <div class="bg-white rounded-xl p-8 border border-slate-200 text-center">
                    <p class="text-lg text-slate-900 font-medium"><?php _e('Fixed-scope', 'neotech'); ?></p>
                </div>
                <div class="bg-white rounded-xl p-8 border border-slate-200 text-center">
                    <p class="text-lg text-slate-900 font-medium"><?php _e('Documented', 'neotech'); ?></p>
                </div>
                <div class="bg-white rounded-xl p-8 border border-slate-200 text-center">
                    <p class="text-lg text-slate-900 font-medium"><?php _e('Contractual', 'neotech'); ?></p>
                </div>
            </div>
            <div class="max-w-3xl mx-auto bg-white rounded-2xl p-10 border border-slate-200 text-center">
                <p class="text-slate-700 text-lg">
                    <?php _e('Our responsibility is to explain options and implications clearly. The client is responsible for the final decision and execution.', 'neotech'); ?>
                </p>
            </div>
        </div>
    </section>
    <?php
    return ob_get_clean();
}
add_shortcode('neotech_engagement', 'neotech_engagement_shortcode');
